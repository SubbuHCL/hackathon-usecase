#!/usr/bin/env bash
# Install the DocGen agent package for Google Antigravity (CLI / IDE / app).
#
# Usage:
#   ./install.sh <target-repo>      workspace install -> <target-repo>/.agents/
#   ./install.sh --global           global install    -> ~/.gemini/config/
#   ./install.sh <target-repo> --dry-run
#
# Existing files are never silently overwritten: a changed same-named agent or
# skill is moved to <root>/.docgen-backup-<timestamp>/ (outside the folders
# Antigravity scans, so backups never load as duplicates). mcp_config.json is
# merged (missing servers added) when jq is available; otherwise the docgen
# servers are written to mcp_config.docgen.json for you to merge by hand.
set -eu

PKG="$(cd "$(dirname "$0")" && pwd)/.agents"
[ -d "$PKG/agents" ] || { echo "ERROR: package folder not found at $PKG" >&2; exit 1; }

DRY=0; DEST=""; MODE=""
for a in "$@"; do
  case "$a" in
    --global) MODE=global ;;
    --dry-run) DRY=1 ;;
    -h|--help) sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) DEST="$a"; MODE="${MODE:-workspace}" ;;
  esac
done
[ -n "$MODE" ] || { sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'; exit 64; }

if [ "$MODE" = global ]; then
  ROOT="$HOME/.gemini/config"
else
  [ -d "$DEST" ] || { echo "ERROR: target repo not found: $DEST" >&2; exit 1; }
  ROOT="$(cd "$DEST" && pwd)/.agents"
fi
TS="$(date +%Y%m%d%H%M%S)"
BK="$ROOT/.docgen-backup-$TS"

run() { if [ "$DRY" -eq 1 ]; then echo "[dry-run] $*"; else "$@"; fi; }

echo "Installing DocGen ($MODE) into: $ROOT"
run mkdir -p "$ROOT/agents" "$ROOT/skills"

# agent
if [ -e "$ROOT/agents/docgen.md" ] && ! cmp -s "$PKG/agents/docgen.md" "$ROOT/agents/docgen.md"; then
  run mkdir -p "$BK/agents"
  run mv "$ROOT/agents/docgen.md" "$BK/agents/docgen.md"
  echo "  backed up changed agents/docgen.md -> .docgen-backup-$TS/"
fi
run cp "$PKG/agents/docgen.md" "$ROOT/agents/docgen.md"
echo "  agent:  agents/docgen.md"

# skills
for s in "$PKG"/skills/*/; do
  name="$(basename "$s")"
  if [ -d "$ROOT/skills/$name" ]; then
    if diff -rq -x .DS_Store "$s" "$ROOT/skills/$name" >/dev/null 2>&1; then
      echo "  skill:  skills/$name (unchanged)"; continue
    fi
    run mkdir -p "$BK/skills"
    run mv "$ROOT/skills/$name" "$BK/skills/$name"
    echo "  backed up changed skills/$name -> .docgen-backup-$TS/"
  fi
  run cp -R "$s" "$ROOT/skills/$name"
  echo "  skill:  skills/$name"
done
if [ "$DRY" -eq 0 ]; then
  find "$ROOT/skills" -path "*/scripts/*.sh" -exec chmod +x {} +
  find "$ROOT/skills" -name ".DS_Store" -delete 2>/dev/null || true
fi

# MCP servers
CFG="$ROOT/mcp_config.json"
if [ ! -f "$CFG" ]; then
  run cp "$PKG/mcp_config.json" "$CFG"
  echo "  mcp:    mcp_config.json (codegraph, mermaid)"
elif command -v jq >/dev/null 2>&1; then
  if [ "$DRY" -eq 0 ]; then
    MERGED="$(jq -s '.[0] as $cur | .[1] as $pkg
           | $cur | .mcpServers = (($pkg.mcpServers) + ($cur.mcpServers // {}))' "$CFG" "$PKG/mcp_config.json")"
    if [ "$(jq -S . "$CFG")" != "$(printf '%s' "$MERGED" | jq -S .)" ]; then
      mkdir -p "$BK"; cp "$CFG" "$BK/mcp_config.json"
      printf '%s\n' "$MERGED" > "$CFG"
      echo "  mcp:    merged codegraph + mermaid into existing mcp_config.json (existing entries kept; backup in .docgen-backup-$TS/)"
    else
      echo "  mcp:    mcp_config.json already has the docgen servers"
    fi
  fi
else
  run cp "$PKG/mcp_config.json" "$ROOT/mcp_config.docgen.json"
  echo "  mcp:    existing mcp_config.json left untouched; merge mcp_config.docgen.json into it by hand (jq not found)"
fi

echo
echo "Next steps:"
echo "  1. Install CodeGraph if needed:  npm i -g @colbymchenry/codegraph"
if [ "$MODE" = workspace ]; then
  echo "  2. Check tools:                   bash \"$ROOT/skills/docgen-analyser/scripts/preflight.sh\" \"$(dirname "$ROOT")\""
  echo "  3. Suggest to the repo owner: add '.codegraph/' and 'docs/.docgen/' to .gitignore"
else
  echo "  2. Check tools:                   bash \"$ROOT/skills/docgen-analyser/scripts/preflight.sh\" <repo>"
fi
echo "  4. Start Antigravity in the repo, pick the 'docgen' agent (/agents), and say: document this repository"
