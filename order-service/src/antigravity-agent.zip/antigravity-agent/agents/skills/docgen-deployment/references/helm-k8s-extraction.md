# Helm and Kubernetes extraction (8b to 8g)

`{chart}` is a chart root reported by `discover-deploy.sh`. Use `view_file`
for YAML files. The commands below are for quick targeted lookups.

## 8b: Chart metadata and values

Read `{chart}/Chart.yaml`, `{chart}/values.yaml` and every `{chart}/values-*.yaml`.

Record:
- From `Chart.yaml`: name, version, appVersion (usually the image tag),
  description, and `dependencies[]` (subcharts).
- From the values files:
  - `image.repository`, `image.tag`
  - `replicaCount`
  - `resources.requests` / `resources.limits`
  - probes (liveness, readiness, startup)
  - `service.type` and `service.port`
  - `ingress` (enabled, className, hosts, paths, tls)
  - `autoscaling` (enabled, min, max, metric)
  - `podDisruptionBudget`
  - `serviceAccount` (name, annotations)
  - `env` / `envFrom` / `extraEnv`

## 8c: Archetype and enabled templates

| Template present | Meaning |
|---|---|
| `deployment.yaml` | api, frontend or worker (worker if there is no service or ingress) |
| `statefulset.yaml` | stateful workload |
| `cronjob.yaml` / `job.yaml` | scheduled or batch |
| `service.yaml` | in-cluster exposure |
| `ingress.yaml` | external HTTP exposure |
| `configmap.yaml` | non-secret env |
| `secret.yaml` | k8s-native secrets |
| `external-secret.yaml` | external-secrets operator (Vault, AWS SM, GCP SM, Azure KV) |
| `hpa.yaml` | autoscaling |
| `pdb.yaml` | disruption budget |
| `serviceaccount.yaml` | identity (IRSA, Workload Identity) |

Read each template that is present and note its conditionals
(`{{- if .Values.x.enabled }}`), because a disabled feature must not be drawn.

## 8d: Configuration injection, the env var source map

```bash
grep -rnE "configMapKeyRef|secretKeyRef|envFrom|valueFrom" {chart}/templates/
```

Classify every env var that reaches the container:

| Source value | How it arrives |
|---|---|
| `literal` | inline `value:` in the workload template or values |
| `ConfigMap:<name>` | `envFrom.configMapRef` or `valueFrom.configMapKeyRef` |
| `Secret:<name>` | `envFrom.secretRef` or `valueFrom.secretKeyRef` |
| `ExternalSecret:<store>` | `external-secret.yaml` → `secretStoreRef` → backend |

For an ExternalSecret, record `secretStoreRef.name`/`kind`, `refreshInterval`,
`target.name`, and each `data[].remoteRef.key`. Join this map with
`05-config.md` by variable name.

## 8e: Network topology

```bash
grep -nE "hosts:|host:|paths:|path:|className:|ingressClassName:|tls:|secretName:" {chart}/templates/ingress.yaml {chart}/values*.yaml
grep -nE "type:|port:|targetPort:|nodePort:" {chart}/templates/service.yaml {chart}/values*.yaml
```

Record:
- ingress class, host(s), path(s), and the TLS source (a cert-manager issuer
  annotation, a static secretName, or none)
- service type (ClusterIP, NodePort or LoadBalancer), port and targetPort
- the container port

## 8f: Scaling, resilience and identity

```bash
grep -nE -A4 "livenessProbe:|readinessProbe:|startupProbe:" {chart}/values*.yaml {chart}/templates/*.yaml
grep -nE -A4 "resources:" {chart}/values*.yaml
grep -nE "minReplicas|maxReplicas|targetCPU|averageUtilization|minAvailable|maxUnavailable" {chart}/values*.yaml {chart}/templates/*.yaml
grep -nE "serviceAccount|role-arn|iam.gke.io|azure.workload.identity" {chart}/values*.yaml {chart}/templates/*.yaml
```

Record:
- probe method, path, port and period
- CPU and memory requests and limits per environment
- HPA min, max and metric
- PDB setting
- ServiceAccount name, and its IRSA, GCP or Azure workload identity annotation

## 8g: Environment matrix

Compare `values-dev.yaml`, `values-staging.yaml` and `values-prod.yaml`
(whichever exist) on: replicas, image tag, resources, ingress host, HPA
bounds, and feature toggles. **Keep only the rows that differ.** If only
`values.yaml` exists, write "single environment (defaults only)".

## Plain manifests and Kustomize

Apply the same extraction to plain `Deployment`, `Service` and `Ingress`
YAML. For Kustomize, read `base/` and then each overlay's patches. An overlay
is an environment.
