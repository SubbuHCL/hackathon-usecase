# Icon catalog for architecture-beta diagrams

Use the search query in `search_mermaid_icons` (Mermaid MCP), and take the
first result whose id matches the technology. The ids in the last column are
**typical results, not guarantees**. Use an id only if the search returned
it, or if `validate_and_render_mermaid_diagram` renders it successfully.

Without the MCP, use the built-in shapes only: `cloud`, `server`,
`database`, `disk`, `internet`.

| Node | Query (AWS / Azure / GCP) | Typical ids |
|---|---|---|
| Cloud root | `aws cloud` / `azure cloud` / `gcp cloud` | `logos:aws`, `logos:microsoft-azure`, `logos:google-cloud` |
| VPC / VNet | `vpc` / `virtual network` / `vpc network` | `aws:arch-amazon-vpc`, `azure:virtual-networks`, `gcp:virtual-private-cloud` |
| Subnet | `private subnet` / `subnet` | `aws:res-amazon-vpc-private-subnet`, `azure:subnet`, `gcp:subnetwork` |
| Kubernetes | `eks` / `aks` / `gke` / `kubernetes` | `aws:arch-amazon-eks`, `azure:kubernetes-services`, `gcp:kubernetes-engine`, `logos:kubernetes` |
| Compute / VM | `ec2` / `virtual machine` / `compute engine` | `aws:arch-amazon-ec2`, `azure:virtual-machine`, `gcp:compute-engine` |
| Serverless containers | `fargate` / `container apps` / `cloud run` | `aws:arch-aws-fargate`, `azure:container-apps-environments`, `gcp:cloud-run` |
| Registry | `ecr` / `container registry` / `artifact registry` | `aws:arch-amazon-elastic-container-registry`, `azure:container-registries`, `gcp:artifact-registry` |
| Load balancer / ingress | `application load balancer` / `application gateway` / `cloud load balancing` | `aws:arch-elastic-load-balancing`, `azure:application-gateways`, `gcp:cloud-load-balancing` |
| API gateway | `api gateway` / `api management` / `apigee` | `aws:arch-amazon-api-gateway`, `azure:api-management-services`, `gcp:apigee-api-platform` |
| DNS | `route 53` / `dns zone` / `cloud dns` | `aws:arch-amazon-route-53`, `azure:dns-zones`, `gcp:cloud-dns` |
| Relational DB | `rds` / `azure database postgresql` / `cloud sql` | `aws:arch-amazon-rds`, `azure:azure-database-postgresql-server`, `gcp:cloud-sql` |
| Document DB | `dynamodb` / `cosmos db` / `firestore` | `aws:arch-amazon-dynamodb`, `azure:azure-cosmos-db`, `gcp:firestore` |
| Cache | `elasticache` / `cache redis` / `memorystore` | `aws:arch-amazon-elasticache`, `azure:cache-redis`, `gcp:memorystore` |
| Kafka / queue | `msk` / `sqs` / `service bus` / `event hubs` / `pub sub` / `kafka` | `aws:arch-amazon-managed-streaming-for-apache-kafka`, `aws:arch-amazon-simple-queue-service`, `azure:service-bus`, `azure:event-hubs`, `gcp:pub-sub`, `logos:kafka` |
| Object storage | `s3` / `storage account` / `cloud storage` | `aws:arch-amazon-simple-storage-service`, `azure:storage-accounts`, `gcp:cloud-storage` |
| Secrets | `secrets manager` / `key vault` / `secret manager` / `vault` | `aws:arch-aws-secrets-manager`, `azure:key-vaults`, `gcp:secret-manager`, `logos:vault` |
| Identity | `iam` / `entra id` / `managed identity` / `iam` | `aws:arch-aws-identity-and-access-management`, `azure:entra-managed-identities`, `gcp:identity-and-access-management` |
| WAF / edge | `waf` / `front door` / `cloud armor` | `aws:arch-aws-waf`, `azure:front-door-and-cdn-profiles`, `gcp:cloud-armor` |
| Observability | `cloudwatch` / `azure monitor` / `application insights` / `cloud monitoring` | `aws:arch-amazon-cloudwatch`, `azure:monitor`, `azure:application-insights`, `gcp:cloud-monitoring` |
| Source repo | `github` / `gitlab` / `bitbucket` / `azure devops` | `logos:github-icon`, `logos:gitlab`, `logos:bitbucket`, `azure:azure-devops` |
| CI/CD | `github actions` / `jenkins` / `gitlab` / `azure pipelines` / `codepipeline` / `cloud build` | `logos:github-actions`, `logos:jenkins`, `logos:gitlab`, `azure:pipelines`, `aws:arch-aws-codepipeline`, `gcp:cloud-build` |
| GitOps | `argo` / `flux` | `logos:argo-icon`, `logos:flux` |
| Helm | `helm` | `logos:helm` |
| Client / browser | `browser` / `user` | `logos:chrome`, `mdi:web`, `mdi:account` |

Rules:
1. Make one search per distinct technology, and reuse the result for
   repeated nodes.
2. If several providers appear (for example, AKS with a Vault store), each
   node uses its own vendor's icon.
3. Datastores, queues and identity providers should use their brand icon,
   not a generic `database` or `disk` shape, whenever the search returns one.
