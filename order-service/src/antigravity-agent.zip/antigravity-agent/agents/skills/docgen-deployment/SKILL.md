---
name: docgen-deployment
description: Discovers and analyses deployment artifacts (Helm charts, Kubernetes manifests, Terraform/Bicep/CloudFormation/Pulumi IaC, CI/CD pipelines), traces configuration and secret injection, and plans icon-rich cloud architecture diagrams. Use during docgen phases 8 and 9, or whenever DEPLOYMENT.md or a deployment diagram is requested.
---

# DocGen Deployment (phases 8 and 9)

A full deployment picture has three layers, and each comes from one artifact
family:

| Layer | Family | Typical content |
|---|---|---|
| Cloud resources | IaC (Terraform, Bicep, CloudFormation, Pulumi) | VPC/VNet, cluster, managed DBs, storage, IAM, secrets store, DNS, LB |
| Workload | Helm or Kubernetes manifests | namespace, Deployment/StatefulSet/CronJob, Service, Ingress, ConfigMap, Secret, HPA, PDB, ServiceAccount |
| Delivery | CI/CD pipeline | triggers, build/test/scan, image push, deploy mechanism, promotion |

Output: `{TARGET}/docs/.docgen/facts/08-deployment.md`. This file feeds
DEPLOYMENT.md, the CONFIGURATION.md delivery-source column, the RUNBOOK
Kubernetes section, and the ARCHITECTURE.md deployment view.

## 8a: Discover and reconcile

```bash
bash {SKILLS}/docgen-deployment/scripts/discover-deploy.sh {TARGET} [external paths the user gave in Step 1]
```

Classify each family as `found`, `partial` or `missing`. If any family is
`missing`, the user has not already declined it, and they did not say
"figure it out", ask:

> I found these deployment artifacts:
> - IaC: {found: files | partial: what | missing}
> - Helm / k8s: {...}
> - CI/CD: {...}
>
> For each missing family, reply with one of:
> 1. A path to the files (for example, a sibling repo). I will read them.
> 2. A short description (for example, "EKS in eu-west-1, RDS Postgres, S3
>    for exports"). I will draw those nodes marked `user-described`.
> 3. "skip". I will label that layer `not provided`.

STOP and wait. Record the answer per family in `state.md` → Decisions.

**Never invent cloud resources.** Every node needs a source:
`iac:<file>`, `helm:<file>`, `k8s:<file>`, `pipeline:<file>`, or
`user-described`. A partial diagram labelled `not provided` is better than a
confident, hallucinated one.

## 8b to 8g: Extract (Helm and Kubernetes)

Follow `references/helm-k8s-extraction.md`. It covers chart metadata,
archetype, config injection (the env var source map), network topology,
scaling, resilience and identity, and the dev/prod environment matrix. Skip
`_helpers.tpl`, `NOTES.txt` and `.helmignore`; they are plumbing.

## 8h: Extract (IaC and pipeline)

- **IaC**: use `view_file` on the files listed by the discovery script. Capture:
  - provider and region
  - network (VPC/VNet, subnets, NAT/IGW)
  - cluster (name, version, node groups)
  - data services (RDS, ElastiCache, S3, DynamoDB, Cosmos, Cloud SQL, ...)
  - identity (IAM roles, IRSA, managed identities)
  - secrets store
  - edge (LB, API gateway, WAF, DNS)
  - observability

  Each item cites `file:line`.
- **Pipeline**: capture:
  - triggers
  - ordered stages
  - image registry (match it to Helm `image.repository`)
  - deploy mechanism (helm, kubectl, ArgoCD, Flux, terraform)
  - promotion gates (environments, manual approvals)

## 9: Plan the diagrams

Write a diagram plan into the facts file **before** drawing. Use a table of
node, layer, label, technology, source, and icon search query. Then hand off
to the **mermaid-diagrams** skill to resolve icons and validate.

1. Detect the provider from IaC first, then Helm values (registry and ingress
   class), then ServiceAccount annotations (IRSA means AWS,
   `iam.gke.io` means GCP, `azure.workload.identity` means Azure), then
   ExternalSecret stores.
2. Pick icons with `references/icon-catalog.md`. Resolve every icon through
   the Mermaid MCP `search_mermaid_icons` tool when it is available. Never
   invent an icon id. Without the MCP, use the generic `architecture-beta`
   shapes (`cloud`, `server`, `database`, `disk`, `internet`).
3. Layer the diagram: internet → cloud → network → cluster → namespace →
   workload, with datastores, secrets and observability alongside, and the
   delivery path (repo → CI → registry → cluster).
4. Keep it to 25 nodes or fewer. If there are more, split it into network,
   data, identity and delivery diagrams.
5. Omit `not provided` layers entirely, and add a note under the diagram that
   names them.

## Exit checklist

- [ ] Every family is classified and the user's choice is recorded.
- [ ] Every env var reaching the container has a delivery source.
- [ ] Ingress, service, ports, probes, resources, HPA, PDB and identity are
      recorded, or marked absent.
- [ ] The dev/prod matrix lists only rows that differ.
- [ ] The diagram plan cites a source for every node.
