#!/usr/bin/env bash
# Discover deployment artifacts (Helm/k8s, IaC, CI/CD) and the cloud provider.
# Usage: discover-deploy.sh <target-dir> [extra-dir ...]
#   extra-dir: external/sibling repos the user supplied (IaC, charts, pipelines)
# Prints a markdown report. Every item is a file path to read next.
set -u
LIB="$(cd "$(dirname "$0")/../../docgen-analyser/scripts" && pwd)/lib.sh"
. "$LIB"

[ $# -ge 1 ] && [ -d "$1" ] || { echo "usage: discover-deploy.sh <target-dir> [extra-dir ...]" >&2; exit 64; }

yaml_grep_files() { # <dir> <ERE>
  ( cd "$1" && grep -rlE "${GREP_EXCLUDES[@]}" --include=*.yaml --include=*.yml --include=*.json -- "$2" . 2>/dev/null ) | sed 's|^\./||' | sort
}

scan() {
  local R="$1"
  echo "## Scan root: \`$R\`"
  echo

  # ---------------- Helm ----------------
  echo "### Helm charts"
  CHARTS="$(ffind "$R" -name Chart.yaml | grep -v '/charts/.*/charts/')"
  if [ -z "$CHARTS" ]; then
    echo "- none"
  else
    for c in $CHARTS; do
      d="$(dirname "$c")"
      n="$(grep -E '^name:' "$R/$c" | head -1 | sed 's/name:[[:space:]]*//')"
      v="$(grep -E '^version:' "$R/$c" | head -1 | sed 's/version:[[:space:]]*//')"
      a="$(grep -E '^appVersion:' "$R/$c" | head -1 | sed 's/appVersion:[[:space:]]*//')"
      echo "- chart \`$n\` version \`$v\` appVersion \`$a\` at \`$d/\`"
      vals="$(cd "$R/$d" && ls values*.y*ml 2>/dev/null | tr '\n' ' ')"
      echo "  - values files: ${vals:-none}"
      tpl=""
      for t in deployment statefulset cronjob job daemonset service ingress configmap secret external-secret hpa pdb serviceaccount networkpolicy servicemonitor; do
        [ -f "$R/$d/templates/$t.yaml" ] && tpl="$tpl $t"
      done
      others="$(cd "$R/$d/templates" 2>/dev/null && ls *.yaml 2>/dev/null | sed 's/\.yaml$//' | tr '\n' ' ')"
      echo "  - templates (known):${tpl:- none}"
      echo "  - templates (all): ${others:-none}"
      arch="unknown"
      case "$tpl" in
        *statefulset*) arch="stateful" ;;
        *cronjob*) arch="cronjob" ;;
        *deployment*) case "$tpl" in *ingress*|*service*) arch="api or frontend" ;; *) arch="worker" ;; esac ;;
      esac
      echo "  - archetype guess: $arch"
      deps="$(awk '/^dependencies:/{f=1;next} f && /^[^ -]/{f=0} f && /name:/{sub(/.*name:[ ]*/,""); printf "%s ", $0}' "$R/$c")"
      [ -n "$deps" ] && echo "  - chart dependencies: $deps"
    done
  fi
  echo

  # ---------------- Plain k8s ----------------
  echo "### Kubernetes manifests (outside charts)"
  K8S="$(yaml_grep_files "$R" '^kind: *(Deployment|StatefulSet|CronJob|DaemonSet|Service|Ingress|ConfigMap|Secret|ExternalSecret|HorizontalPodAutoscaler|PodDisruptionBudget|Kustomization)[[:space:]]*$' | grep -v '/templates/')"
  if [ -n "$K8S" ]; then
    for f in $K8S; do
      kinds="$(grep -hE '^kind:' "$R/$f" | sed 's/kind:[[:space:]]*//' | sort -u | tr '\n' ' ')"
      echo "- \`$f\`: $kinds"
    done | cap 30
  else
    echo "- none"
  fi
  KUST="$(ffind "$R" -name kustomization.yaml -o -name kustomization.yml)"
  [ -n "$KUST" ] && { echo "- kustomize overlays:"; printf '%s\n' "$KUST" | sed 's/^/  - /'; }
  echo

  # ---------------- IaC ----------------
  echo "### Infrastructure-as-Code"
  TF="$(ffind "$R" -name "*.tf")"
  if [ -n "$TF" ]; then
    echo "- Terraform files: $(printf '%s\n' "$TF" | grep -c .)"
    printf '%s\n' "$TF" | cap 15 | sed 's/^/  - /'
    echo "- providers: $( (cd "$R" && grep -hoE 'provider[[:space:]]+"[a-z0-9_-]+"' $TF 2>/dev/null) | sed 's/provider[[:space:]]*//; s/"//g' | sort -u | tr '\n' ' ')"
    echo "- resources by type:"
    (cd "$R" && grep -hoE '^[[:space:]]*resource[[:space:]]+"[a-z0-9_]+"[[:space:]]+"[A-Za-z0-9_-]+"' $TF 2>/dev/null) |
      awk '{ gsub(/"/, ""); print $2 "\t" $3 }' | sort | awk -F'\t' '{ n[$1]++; ex[$1] = (ex[$1] == "" ? $2 : ex[$1]) } END { for (t in n) printf "  - %s x%d (e.g. %s)\n", t, n[t], ex[t] }' | sort | cap 40
    echo "- modules:"
    (cd "$R" && grep -hE '^[[:space:]]*source[[:space:]]*=' $TF 2>/dev/null) | sed 's/^[[:space:]]*/  - /' | sort -u | cap 15
  else
    echo "- Terraform: none"
  fi
  B="$(ffind "$R" -name "*.bicep")"
  [ -n "$B" ] && { echo "- Bicep:"; printf '%s\n' "$B" | sed 's/^/  - /'; echo "  - resource types: $( (cd "$R" && grep -hoE "^resource [A-Za-z0-9_]+ '[^@']+" $B) | awk '{print $3}' | tr -d "'" | sort -u | tr '\n' ' ')"; }
  CFN="$(yaml_grep_files "$R" 'AWSTemplateFormatVersion')"
  [ -n "$CFN" ] && { echo "- CloudFormation:"; printf '%s\n' "$CFN" | sed 's/^/  - /'; echo "  - resource types: $( (cd "$R" && grep -hoE 'Type:[[:space:]]*"?AWS::[A-Za-z0-9:]+' $CFN) | sed 's/Type:[[:space:]]*"*//' | sort -u | tr '\n' ' ')"; }
  P="$(ffind "$R" -name Pulumi.yaml)"
  [ -n "$P" ] && { echo "- Pulumi:"; printf '%s\n' "$P" | sed 's/^/  - /'; }
  echo

  # ---------------- CI/CD ----------------
  echo "### CI/CD pipelines"
  PIPES="$(ffind "$R" -path "*/.github/workflows/*.y*ml" -o -name "Jenkinsfile*" -o -name ".gitlab-ci.yml" -o -name "azure-pipelines*.yml" -o -path "*/.azure-pipelines/*.yml" -o -name "buildspec.y*ml" -o -path "*/.circleci/config.yml" -o -path "*/.buildkite/*.yml" -o -name "cloudbuild.y*ml" -o -name "bitbucket-pipelines.yml" -o -name "skaffold.y*ml")"
  if [ -n "$PIPES" ]; then
    for f in $PIPES; do
      h=""
      grep -qE 'helm (upgrade|install)' "$R/$f" && h="$h helm"
      grep -qE 'kubectl apply' "$R/$f" && h="$h kubectl"
      grep -qiE 'argocd|argo-cd' "$R/$f" && h="$h argocd"
      grep -qiE 'flux' "$R/$f" && h="$h flux"
      grep -qE 'terraform (apply|plan)' "$R/$f" && h="$h terraform"
      grep -qE 'docker (build|push)|docker/build-push-action|buildx|kaniko|jib' "$R/$f" && h="$h image-build"
      grep -qE 'sonar|trivy|snyk|codeql' "$R/$f" && h="$h scan"
      echo "- \`$f\`:${h:- (read to classify)}"
    done
  else
    echo "- none"
  fi
  GITOPS="$(yaml_grep_files "$R" '^kind: *(Application|ApplicationSet|HelmRelease|Kustomization)[[:space:]]*$' | head -10)"
  [ -n "$GITOPS" ] && { echo "- GitOps manifests (ArgoCD/Flux):"; printf '%s\n' "$GITOPS" | sed 's/^/  - /'; }
  echo

  # ---------------- provider ----------------
  echo "### Cloud provider signals"
  sig() { ( cd "$R" && grep -rlE "${GREP_EXCLUDES[@]}" --include=*.tf --include=*.bicep --include=*.yaml --include=*.yml --include=*.json --include=Jenkinsfile -- "$1" . 2>/dev/null ) | grep -c . ; }
  AWS=$(sig 'provider "aws"|aws_[a-z_]+|amazonaws\.com|eks\.amazonaws\.com/role-arn|AWS::|\.ecr\.')
  AZ=$(sig 'azurerm|azurecr\.io|azure\.workload\.identity|Microsoft\.[A-Za-z]+/|AzureKeyVault')
  GCP=$(sig 'provider "google"|google_[a-z_]+|gcr\.io|pkg\.dev|iam\.gke\.io')
  echo "| Provider | Files with signals |"
  echo "|---|---|"
  echo "| AWS | $AWS |"
  echo "| Azure | $AZ |"
  echo "| GCP | $GCP |"
  echo
}

for root in "$@"; do
  if [ -d "$root" ]; then scan "$(cd "$root" && pwd)"; else echo "## Scan root: \`$root\`: NOT FOUND"; echo; fi
done

echo "### Next"
echo "- Classify each family as found / partial / missing (SKILL.md step 8a)."
echo "- Read every chart's Chart.yaml, values*.yaml and the known templates listed above."
