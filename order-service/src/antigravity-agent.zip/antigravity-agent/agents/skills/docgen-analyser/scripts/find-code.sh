#!/usr/bin/env bash
# Locate candidate code for one docgen category (grep fallback for the graph).
# Usage: find-code.sh <target-dir> <category> [--count] [--max N]
# Categories:
#   entrypoints controllers grpc graphql entities repositories migrations
#   consumers producers clients config security scheduled tests all
# Output: "file:line: text" (capped), or "<category>\t<count>" with --count.
set -u
. "$(cd "$(dirname "$0")" && pwd)/lib.sh"

TARGET="${1:-}"; CAT="${2:-}"; shift 2 2>/dev/null || true
COUNT_ONLY=0; MAX=80
while [ $# -gt 0 ]; do
  case "$1" in
    --count) COUNT_ONLY=1 ;;
    --max) shift; MAX="${1:-80}" ;;
  esac
  shift
done

if [ -z "$TARGET" ] || [ -z "$CAT" ] || [ ! -d "$TARGET" ]; then
  sed -n '2,8p' "$0" | sed 's/^# \{0,1\}//'
  exit 64
fi

pattern_for() {
  case "$1" in
    entrypoints)  echo '@SpringBootApplication|fun main\(|func main\(\)|NestFactory\.create|\.listen\([0-9A-Za-z_]+|FastAPI\(|Flask\(__name__\)|__name__ == .__main__.|WebApplication\.CreateBuilder|static void Main\(' ;;
    controllers)  echo '@RestController|@Controller([^A-Za-z]|$)|@(Get|Post|Put|Patch|Delete|Request)Mapping|@Path\(|@(Get|Post|Put|Patch|Delete)\(|(router|app|server)\.(get|post|put|patch|delete)\(|HandleFunc\(|\.(GET|POST|PUT|PATCH|DELETE)\(|@(app|router|bp|blueprint)\.(get|post|put|patch|delete|route)\(|\[Http(Get|Post|Put|Patch|Delete)|routing *\{' ;;
    grpc)         echo 'extends [A-Za-z]+ImplBase|@GrpcService|Register[A-Za-z]+Server\(|add_[A-Za-z]+Servicer_to_server|@GrpcMethod' ;;
    graphql)      echo '@QueryMapping|@MutationMapping|@SchemaMapping|@Resolver\(|@Query\(|@Mutation\(|graphene\.|strawberry\.' ;;
    entities)     echo '@Entity|@Table\(|@Document\(|@MappedSuperclass|@Embeddable|@Entity\(|__tablename__|models\.Model\)|gorm\.Model|DeclarativeBase|declarative_base\(|@Schema\(\)|mongoose\.Schema|DbSet<' ;;
    repositories) echo 'extends (JpaRepository|CrudRepository|PagingAndSortingRepository|MongoRepository|ReactiveCrudRepository|ReactiveMongoRepository|R2dbcRepository|CoroutineCrudRepository)|@Repository|: *(JpaRepository|CrudRepository|MongoRepository)<|@InjectRepository\(|getRepository\(' ;;
    consumers)    echo '@KafkaListener|@RabbitListener|@JmsListener|@SqsListener|@StreamListener|@EventListener|@TransactionalEventListener|@EventPattern|@MessagePattern|consumer\.subscribe|\.subscribe\(\{ *topic|@Subscribe|@IncomingMessage|@ServiceBusTrigger|@PubSubListener' ;;
    producers)    echo 'KafkaTemplate|kafkaTemplate\.send|RabbitTemplate|convertAndSend\(|JmsTemplate|StreamBridge|ApplicationEventPublisher|publishEvent\(|producer\.send\(|sqsTemplate|SqsTemplate|SnsTemplate|PubSubTemplate|ServiceBusSender|publisher\.publish\(|\.emit\(|\.send\("[A-Za-z0-9._${}-]+"' ;;
    clients)      echo '@FeignClient|WebClient|RestTemplate|RestClient|java\.net\.http\.HttpClient|OkHttpClient|axios|HttpService|got\(|fetch\(|http\.NewRequest|http\.(Get|Post)\(|requests\.(get|post|put|patch|delete)\(|httpx\.|HttpClient\(' ;;
    config)       echo '@Value\(|@ConfigurationProperties|process\.env\.|os\.Getenv\(|os\.LookupEnv\(|os\.environ|os\.getenv\(|System\.getenv\(|Environment\.getProperty|ConfigService|BaseSettings|IConfiguration|@ConfigProperty' ;;
    security)     echo '@PreAuthorize|@PostAuthorize|@Secured|@RolesAllowed|SecurityFilterChain|@EnableWebSecurity|@EnableMethodSecurity|oauth2ResourceServer|@UseGuards|AuthGuard|passport\.|Depends\(oauth2|\[Authorize' ;;
    scheduled)    echo '@Scheduled|@Cron\(|@EnableScheduling|cron\.schedule|@SchedulerLock|BackgroundService' ;;
    *) return 1 ;;
  esac
}

run_files_category() {
  case "$1" in
    migrations)
      ffind "$TARGET" -path "*db/migration*" -o -path "*db/changelog*" -o -name "*changelog*.xml" -o -name "*changelog*.yaml" -o -name "*changelog*.yml" -o -path "*prisma/migrations*" -o -path "*alembic/versions*" -o -path "*/migrations/*.sql" -o -name "schema.prisma" -o -path "*Migrations/*.cs" ;;
    tests)
      ffind "$TARGET" -name "*Test.java" -o -name "*Tests.java" -o -name "*IT.java" -o -name "*Test.kt" -o -name "*Spec.kt" -o -name "*.spec.ts" -o -name "*.test.ts" -o -name "*.test.js" -o -name "*_test.go" -o -name "test_*.py" -o -name "*_test.py" ;;
    grpc_files)
      ffind "$TARGET" -name "*.proto" ;;
    graphql_files)
      ffind "$TARGET" -name "*.graphqls" -o -name "*.graphql" -o -name "*.gql" ;;
  esac
}

one() {
  local c="$1" out n
  case "$c" in
    migrations|tests)
      out="$(run_files_category "$c")" ;;
    grpc|graphql)
      local pat; pat="$(pattern_for "$c")"
      out="$( { run_files_category "${c}_files"; sgrep "$TARGET" "$pat" | trim_line; } )" ;;
    *)
      local pat; pat="$(pattern_for "$c")" || { echo "unknown category: $c" >&2; return 64; }
      out="$(sgrep "$TARGET" "$pat" | grep -vE '^[^:]+:[0-9]+:[[:space:]]*(import|package|from|using|require)[[:space:](]' | trim_line)" ;;
  esac
  if [ -z "$out" ]; then n=0; else n=$(printf '%s\n' "$out" | wc -l | tr -d ' '); fi
  if [ "$COUNT_ONLY" -eq 1 ]; then
    printf '%s\t%s\n' "$c" "$n"
  else
    echo "## $c ($n matches)"
    [ "$n" -gt 0 ] && printf '%s\n' "$out" | cap "$MAX"
    echo
  fi
}

if [ "$CAT" = "all" ]; then
  for c in entrypoints controllers grpc graphql entities repositories migrations consumers producers clients config security scheduled tests; do
    one "$c"
  done
else
  one "$CAT"
fi
