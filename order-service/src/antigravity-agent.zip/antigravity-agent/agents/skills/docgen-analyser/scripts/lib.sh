#!/usr/bin/env bash
# Shared helpers for docgen scripts. Source it; do not run it.
# Portable to bash 3.2 (macOS /bin/bash) and BSD/GNU grep, find, awk, sed.

DOCGEN_EXCLUDE_DIRS="node_modules .git target build dist out .gradle .idea .vscode vendor .codegraph .venv venv __pycache__ .next .nuxt coverage .terraform bin obj .mvn docs"

DOCGEN_SRC_EXT="java kt kts groovy scala ts tsx js mjs cjs go py cs rb php"

GREP_EXCLUDES=()
for _d in $DOCGEN_EXCLUDE_DIRS; do GREP_EXCLUDES+=("--exclude-dir=$_d"); done

GREP_SRC_INCLUDES=()
for _e in $DOCGEN_SRC_EXT; do GREP_SRC_INCLUDES+=("--include=*.$_e"); done

FIND_PRUNE=()
for _d in $DOCGEN_EXCLUDE_DIRS; do
  if [ ${#FIND_PRUNE[@]} -gt 0 ]; then FIND_PRUNE+=(-o); fi
  FIND_PRUNE+=(-name "$_d")
done

# ffind <dir> <find predicates...>   -> relative file paths, excluded dirs pruned
ffind() {
  local dir="$1"; shift
  ( cd "$dir" && find . \( -type d \( "${FIND_PRUNE[@]}" \) \) -prune -o -type f \( "$@" \) -print 2>/dev/null ) | sed 's|^\./||' | sort
}

# sgrep <dir> <ERE pattern>   -> "file:line:text" over source files
sgrep() {
  ( cd "$1" && grep -rnE "${GREP_EXCLUDES[@]}" "${GREP_SRC_INCLUDES[@]}" -- "$2" . 2>/dev/null ) | sed 's|^\./||'
}

# sgrep_files <dir> <ERE pattern>   -> unique file list over source files
sgrep_files() {
  ( cd "$1" && grep -rlE "${GREP_EXCLUDES[@]}" "${GREP_SRC_INCLUDES[@]}" -- "$2" . 2>/dev/null ) | sed 's|^\./||' | sort
}

# cap <n> : print the first n lines of stdin, then a truncation note
cap() {
  awk -v n="$1" 'NR <= n { print } END { if (NR > n) printf "... [%d more not shown]\n", NR - n }'
}

# trim_line : shorten "file:line:text" lines to 180 chars and squeeze whitespace
trim_line() {
  awk '{ gsub(/[ \t]+/, " "); if (length($0) > 180) print substr($0, 1, 177) "..."; else print }'
}

docgen_today() { date -u +%Y-%m-%d; }
