#!/usr/bin/env bash
# Check that the tools docgen needs are available.
# Usage: preflight.sh <target-dir>
# Exit 0 when all required tools exist (optional tools only warn).
set -u
TARGET="${1:-.}"
FAIL=0

row() { printf '| %-10s | %-8s | %s |\n' "$1" "$2" "$3"; }
echo "| Tool | Status | Notes |"
echo "|---|---|---|"
for t in bash find grep awk sed sort comm mktemp; do
  if command -v "$t" >/dev/null 2>&1; then row "$t" ok "required"; else row "$t" MISSING "required"; FAIL=1; fi
done
if command -v codegraph >/dev/null 2>&1; then
  row codegraph ok "$(codegraph --version 2>/dev/null | head -1) - knowledge graph"
else
  row codegraph missing "recommended: npm i -g @colbymchenry/codegraph"
fi
if command -v mmdc >/dev/null 2>&1; then
  row mmdc ok "local Mermaid render validation"
elif command -v npx >/dev/null 2>&1; then
  row mmdc optional "not installed; set DOCGEN_MMDC_NPX=1 to use npx @mermaid-js/mermaid-cli (downloads Chromium)"
else
  row mmdc optional "not installed; Mermaid is validated via the mermaid MCP server and lint only"
fi
for t in git jq helm; do
  if command -v "$t" >/dev/null 2>&1; then row "$t" ok "optional"; else row "$t" missing "optional"; fi
done

if [ ! -d "$TARGET" ]; then
  echo "ERROR: target directory not found: $TARGET"; exit 1
fi
if ! mkdir -p "$TARGET/docs/.docgen" 2>/dev/null; then
  echo "ERROR: cannot create $TARGET/docs/.docgen (permissions?)"; FAIL=1
fi
[ "$FAIL" -eq 0 ] && echo "PREFLIGHT: ok" || echo "PREFLIGHT: failed"
exit $FAIL
