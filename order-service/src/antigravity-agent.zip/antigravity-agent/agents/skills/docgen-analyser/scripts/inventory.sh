#!/usr/bin/env bash
# Repository inventory for docgen: repo shape, stack, candidate files per phase,
# deployment artifacts, existing docs, and suggested phase applicability.
# Usage: inventory.sh <target-dir> [--quick]
#   --quick  print stack + structure only (no file write); used in Step 1
#   default  full inventory, also written to <target>/docs/.docgen/inventory.md
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
. "$HERE/lib.sh"

TARGET="${1:-}"; MODE="${2:-full}"
[ -d "$TARGET" ] || { echo "usage: inventory.sh <target-dir> [--quick]" >&2; exit 64; }
TARGET="$(cd "$TARGET" && pwd)"

has() { [ -n "$(ffind "$TARGET" "$@" | head -1)" ]; }
list() { ffind "$TARGET" "$@" | cap "${CAP:-15}" | sed 's/^/  - /'; }
bfiles() { ffind "$TARGET" -name pom.xml -o -name "build.gradle" -o -name "build.gradle.kts" -o -name package.json -o -name go.mod -o -name pyproject.toml -o -name requirements.txt -o -name Cargo.toml -o -name "*.csproj"; }
grep_build() { # <ERE> : does any build file mention it?
  local f
  for f in $(bfiles); do grep -qE -- "$1" "$TARGET/$f" 2>/dev/null && return 0; done
  return 1
}

report() {
echo "# DocGen inventory"
echo "- target: \`$TARGET\`"
echo "- generated: $(docgen_today)"
echo

# ---------------- structure ----------------
echo "## Repository structure"
MONO=""
for m in nx.json turbo.json lerna.json pnpm-workspace.yaml rush.json; do [ -f "$TARGET/$m" ] && MONO="$MONO $m"; done
[ -f "$TARGET/pom.xml" ] && grep -q "<modules>" "$TARGET/pom.xml" && MONO="$MONO maven-modules"
for g in settings.gradle settings.gradle.kts; do [ -f "$TARGET/$g" ] && grep -qE "include" "$TARGET/$g" && MONO="$MONO gradle-multi-project"; done
[ -f "$TARGET/package.json" ] && grep -q '"workspaces"' "$TARGET/package.json" && MONO="$MONO npm-workspaces"
BUILD_ROOTS="$(bfiles | xargs -n1 dirname 2>/dev/null | sort -u)"
NROOTS=$(printf '%s\n' "$BUILD_ROOTS" | grep -c . || true)
if [ -n "$MONO" ] || [ "$NROOTS" -gt 1 ]; then
  echo "- shape: **monorepo / multi-module**${MONO:+ (indicators:$MONO)}"
else
  echo "- shape: **single service**"
fi
echo "- build roots ($NROOTS):"
printf '%s\n' "$BUILD_ROOTS" | cap 25 | sed 's/^/  - /'
echo

# ---------------- stack ----------------
echo "## Tech stack (detected)"
echo "- build files:"; CAP=20 list -name pom.xml -o -name "build.gradle" -o -name "build.gradle.kts" -o -name "settings.gradle*" -o -name package.json -o -name go.mod -o -name pyproject.toml -o -name requirements.txt -o -name Cargo.toml -o -name "*.csproj" -o -name "*.sln"
echo "- source files by language:"
ffind "$TARGET" -name "*.java" -o -name "*.kt" -o -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.go" -o -name "*.py" -o -name "*.cs" -o -name "*.scala" -o -name "*.rb" -o -name "*.php" |
  awk -F. '{ c[$NF]++ } END { for (e in c) printf "  - %s: %d\n", e, c[e] }' | sort -t: -k2 -nr
JV="$(grep -hoE '<java.version>[^<]+' "$TARGET/pom.xml" 2>/dev/null | head -1 | sed 's/.*>//')"
[ -z "$JV" ] && JV="$(grep -hoE '(jvmTarget|languageVersion|sourceCompatibility)[^0-9]*[0-9]+' "$TARGET"/build.gradle* 2>/dev/null | grep -oE '[0-9]+$' | head -1)"
[ -n "$JV" ] && echo "- java version: $JV"
SB="$(grep -A2 'spring-boot-starter-parent' "$TARGET/pom.xml" 2>/dev/null | grep -oE '<version>[^<]+' | head -1 | sed 's/.*>//')"
[ -z "$SB" ] && SB="$(grep -hoE "org.springframework.boot['\"]? *\)? *version *['\"]?[0-9.]+" "$TARGET"/build.gradle* 2>/dev/null | grep -oE '[0-9][0-9.]+' | head -1)"
[ -n "$SB" ] && echo "- spring boot: $SB"
echo "- frameworks and libraries:"
FOUND=0
for pair in \
  "spring-boot-starter-web|Spring MVC (REST, servlet)" "spring-boot-starter-webflux|Spring WebFlux (reactive)" \
  "spring-boot-starter-data-jpa|JPA / Hibernate" "spring-boot-starter-data-mongodb|MongoDB" "spring-boot-starter-data-redis|Redis" \
  "spring-boot-starter-security|Spring Security" "spring-boot-starter-actuator|Actuator (health/metrics)" \
  "spring-kafka|Kafka (spring-kafka)" "spring-rabbit|spring-boot-starter-amqp|RabbitMQ" "spring-cloud-starter-openfeign|OpenFeign clients" \
  "spring-cloud-stream|Spring Cloud Stream" "flyway|Flyway migrations" "liquibase|Liquibase migrations" \
  "micrometer-registry|Micrometer metrics" "grpc|gRPC" "graphql|GraphQL" "ktor-server|Ktor" \
  "@nestjs/core|NestJS" "\"express\"|Express" "\"fastify\"|Fastify" "prisma|Prisma" "typeorm|TypeORM" "mongoose|Mongoose" "kafkajs|KafkaJS" \
  "gin-gonic|Gin" "labstack/echo|Echo" "go-chi|Chi" "gorm.io|GORM" \
  "fastapi|FastAPI" "flask|Flask" "django|Django" "sqlalchemy|SQLAlchemy" "celery|Celery" \
  "Microsoft.AspNetCore|ASP.NET Core" "EntityFrameworkCore|Entity Framework Core"; do
  label="${pair##*|}"; re="${pair%|*}"
  if grep_build "$re"; then echo "  - $label"; FOUND=1; fi
done
[ "$FOUND" -eq 0 ] && echo "  - (none recognised; read the build files)"
echo
}

phase_counts() {
echo "## Candidate code per phase"
echo
echo "| Category | Matches |"
echo "|---|---|"
bash "$HERE/find-code.sh" "$TARGET" all --count | awk -F'\t' '{ printf "| %s | %s |\n", $1, $2 }'
echo
echo "Run \`find-code.sh <target> <category>\` to list the matches."
echo
}

specs_runtime_deploy() {
echo "## Specs (cross-check only)"
CAP=10 list -name "openapi*.y*ml" -o -name "openapi*.json" -o -name "swagger*.y*ml" -o -name "swagger*.json" -o -name "*.proto" -o -name "*.graphqls" -o -name "asyncapi*.y*ml"
has -name "openapi*" -o -name "swagger*" -o -name "*.proto" -o -name "*.graphqls" -o -name "asyncapi*" || echo "  - none"
echo
echo "## Runtime"
CAP=10 list -name Dockerfile -o -name "Dockerfile.*" -o -name "*.dockerfile" -o -name "docker-compose*.y*ml" -o -name "compose*.y*ml" -o -name mvnw -o -name gradlew -o -name Makefile -o -name Procfile -o -name ".nvmrc" -o -name ".java-version" -o -name ".tool-versions"
echo
echo "## Deployment artifacts"
HELM=$(ffind "$TARGET" -name Chart.yaml | grep -c . || true)
K8S=$( (cd "$TARGET" && grep -rlE "${GREP_EXCLUDES[@]}" --include=*.yaml --include=*.yml -- '^kind: *(Deployment|StatefulSet|CronJob|Ingress|Service)$' . 2>/dev/null) | grep -c . || true)
TF=$(ffind "$TARGET" -name "*.tf" | grep -c . || true)
BICEP=$(ffind "$TARGET" -name "*.bicep" | grep -c . || true)
CFN=$( (cd "$TARGET" && grep -rlE "${GREP_EXCLUDES[@]}" --include=*.yaml --include=*.yml --include=*.json -- 'AWSTemplateFormatVersion' . 2>/dev/null) | grep -c . || true)
PULUMI=$(ffind "$TARGET" -name "Pulumi.yaml" | grep -c . || true)
PIPE=$(ffind "$TARGET" -path "*/.github/workflows/*.y*ml" -o -name "Jenkinsfile*" -o -name ".gitlab-ci.yml" -o -name "azure-pipelines*.yml" -o -name "buildspec.y*ml" -o -path "*/.circleci/config.yml" -o -path "*/.buildkite/*.yml" -o -name "cloudbuild.y*ml" -o -name "bitbucket-pipelines.yml" | grep -c . || true)
fam() { if [ "$1" -gt 0 ]; then echo "found ($1)"; else echo "missing"; fi; }
echo "| Family | Status |"
echo "|---|---|"
echo "| Helm charts | $(fam "$HELM") |"
echo "| Kubernetes manifests | $(fam "$K8S") |"
echo "| IaC: Terraform / Bicep / CloudFormation / Pulumi | $(fam $((TF + BICEP + CFN + PULUMI))) |"
echo "| CI/CD pipelines | $(fam "$PIPE") |"
echo
echo "## Existing docs"
if [ -d "$TARGET/docs" ] && [ -n "$(cd "$TARGET/docs" && find . -mindepth 1 -maxdepth 1 ! -name .docgen ! -name .DS_Store | head -1)" ]; then
  if grep -rqs "AUTO-GENERATED-START" "$TARGET/docs" 2>/dev/null; then
    echo "- \`docs/\` exists **with** AUTO-GENERATED markers (previous docgen run)."
    grep -rls "AUTO-GENERATED-START" "$TARGET/docs" 2>/dev/null | grep -v '/\.docgen/' | sed "s|^$TARGET/||; s/^/  - /"
  else
    echo "- \`docs/\` exists without docgen markers (human docs; do not overwrite, write alongside)."
  fi
else
  echo "- no \`docs/\` directory"
fi
if [ -d "$TARGET/.codegraph" ]; then echo "- CodeGraph index: present"; else echo "- CodeGraph index: absent"; fi
echo
}

applicability() {
c() { bash "$HERE/find-code.sh" "$TARGET" "$1" --count | cut -f2; }
yn() { if [ "$1" -gt 0 ]; then echo "run"; else echo "skip (nothing found)"; fi; }
API=$(( $(c controllers) + $(c grpc) + $(c graphql) ))
DATA=$(( $(c entities) + $(c repositories) + $(c migrations) ))
EVT=$(( $(c consumers) + $(c producers) ))
OUT=$(c clients)
RT=$(ffind "$TARGET" -name Dockerfile -o -name "docker-compose*.y*ml" -o -name mvnw -o -name gradlew -o -name Makefile | grep -c . || true)
DEP=$((HELM + K8S + TF + BICEP + CFN + PULUMI + PIPE))
echo "## Suggested phase applicability"
echo
echo "| Phase | Suggestion | Output file |"
echo "|---|---|---|"
echo "| 1 Tech stack | run | README.md, DEPENDENCIES.md |"
echo "| 2 API | $(yn $API) | API.md |"
echo "| 3 Data model | $(yn $DATA) | DATA_MODEL.md |"
echo "| 4 Events | $(yn $EVT) | EVENTS.md |"
echo "| 5 Configuration | run | CONFIGURATION.md |"
echo "| 6 Outbound deps | $(yn $OUT) | ARCHITECTURE.md, DEPENDENCIES.md |"
echo "| 7 Runtime | $(yn $RT) | RUNBOOK.md |"
echo "| 8-9 Deployment | $(yn $DEP) | DEPLOYMENT.md, ARCHITECTURE.md |"
echo
echo "User answers override these suggestions."
}

if [ "$MODE" = "--quick" ]; then
  report
  specs_runtime_deploy
  exit 0
fi

mkdir -p "$TARGET/docs/.docgen"
{ report; phase_counts; specs_runtime_deploy; applicability; } | tee "$TARGET/docs/.docgen/inventory.md"
echo
echo "(written to docs/.docgen/inventory.md)"
