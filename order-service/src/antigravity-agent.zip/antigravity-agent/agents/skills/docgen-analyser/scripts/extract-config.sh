#!/usr/bin/env bash
# Extract configuration inputs from config files and source code.
# Usage: extract-config.sh <target-dir>
# Sections:
#   A. ${VAR:default} placeholders in application*/bootstrap* config files
#   B. ${key:default} placeholders in JVM source (@Value, @FeignClient url, ...)
#   C. @ConfigurationProperties prefixes
#   D. Direct env reads in code (process.env, os.Getenv, os.environ, System.getenv ...)
#   E. .env.example keys and cross-check against A-D
set -u
. "$(cd "$(dirname "$0")" && pwd)/lib.sh"

TARGET="${1:-}"
[ -d "$TARGET" ] || { echo "usage: extract-config.sh <target-dir>" >&2; exit 64; }

TMP="$(mktemp -d 2>/dev/null || mktemp -d -t docgen)"
trap 'rm -rf "$TMP"' EXIT

# Emits: name<TAB>default<TAB>hasDefault<TAB>key<TAB>file:line
placeholder_awk='
{
  file = FILENAME; sub(/^\.\//, "", file)
  line = $0; key = line
  sub(/^[ \t-]*/, "", key); sub(/[:=].*$/, "", key)
  # YAML: rebuild dotted key from indentation
  if (file ~ /\.ya?ml$/ && match($0, /^[ \t]*[A-Za-z0-9_.-]+:/)) {
    ind = match($0, /[^ ]/) - 1; k = $0; sub(/^[ \t]*/, "", k); sub(/:.*/, "", k)
    stack[ind] = k; for (i in stack) if (i + 0 > ind) delete stack[i]
    full = ""; for (j = 0; j <= ind; j++) if (j in stack) full = (full == "" ? stack[j] : full "." stack[j])
    key = full
  }
  while (match(line, /\$\{[^}]+\}/)) {
    tok = substr(line, RSTART + 2, RLENGTH - 3); line = substr(line, RSTART + RLENGTH)
    name = tok; def = ""; has = "no"
    if (index(tok, ":") > 0) { name = substr(tok, 1, index(tok, ":") - 1); def = substr(tok, index(tok, ":") + 1); has = "yes" }
    printf "%s\t%s\t%s\t%s\t%s:%d\n", name, def, has, key, file, FNR
  }
}'

echo "# Configuration inputs (candidates; confirm before documenting)"
echo

# ---- A ----
CFG_FILES="$(ffind "$TARGET" -name "application*.yml" -o -name "application*.yaml" -o -name "application*.properties" -o -name "bootstrap*.yml" -o -name "bootstrap*.yaml" -o -name "bootstrap*.properties" -o -name "appsettings*.json" -o -name "config*.yaml" -o -name "config*.yml")"
echo "## A. Placeholders in config files"
if [ -n "$CFG_FILES" ]; then
  echo "Files: $(printf '%s ' $CFG_FILES)"
  echo
  echo "| Variable | Default | Required | Property key | Source |"
  echo "|---|---|---|---|---|"
  ( cd "$TARGET" && for f in $CFG_FILES; do awk "$placeholder_awk" "$f"; done ) > "$TMP/a.tsv"
  awk -F'\t' '{ req = ($3 == "yes") ? "No" : "Yes"; d = ($3 == "yes") ? ($2 == "" ? "(empty)" : $2) : "-"
               printf "| `%s` | `%s` | %s | `%s` | `%s` |\n", $1, d, req, $4, $5 }' "$TMP/a.tsv"
else
  echo "No application/bootstrap config files found."
  : > "$TMP/a.tsv"
fi
echo

# ---- B ----
echo "## B. Placeholders in JVM source (@Value, @FeignClient(url=...), @Scheduled(cron=...))"
( cd "$TARGET" && grep -rnE "${GREP_EXCLUDES[@]}" --include=*.java --include=*.kt --include=*.groovy --include=*.scala -- '"[^"]*\$\{[A-Za-z_][A-Za-z0-9_.-]*(:[^}]*)?\}' . 2>/dev/null ) | sed 's|^\./||' | awk '
  {
    split($0, p, ":"); src = p[1] ":" p[2]
    if (match($0, /\$\{[^}]+\}/)) {
      tok = substr($0, RSTART + 2, RLENGTH - 3); name = tok; def = "-"
      if (index(tok, ":") > 0) { name = substr(tok, 1, index(tok, ":") - 1); def = substr(tok, index(tok, ":") + 1) }
      env = toupper(name); gsub(/[.-]/, "_", env)
      printf "| `%s` | `%s` | `%s` | `%s` |\n", name, def, env, src
    }
  }' > "$TMP/b.md"
if [ -s "$TMP/b.md" ]; then
  echo "| Property | Default | Env override (relaxed binding) | Source |"
  echo "|---|---|---|---|"
  cat "$TMP/b.md"
else
  echo "None found."
fi
echo

# ---- C ----
echo "## C. @ConfigurationProperties classes"
sgrep "$TARGET" '@ConfigurationProperties' | trim_line | sed 's/^/- /' > "$TMP/c.md"
if [ -s "$TMP/c.md" ]; then cat "$TMP/c.md"; echo; echo "Read each class: every field becomes <prefix>.<field> (env: PREFIX_FIELD)."; else echo "None found."; fi
echo

# ---- D ----
echo "## D. Direct environment reads in code"
sgrep "$TARGET" 'process\.env\.[A-Z_][A-Z0-9_]*|process\.env\[|os\.Getenv\("|os\.LookupEnv\("|os\.environ(\.get)?[\[(]|os\.getenv\(|System\.getenv\(|Environment\.GetEnvironmentVariable\(' |
  awk '
    {
      split($0, p, ":"); src = p[1] ":" p[2]; t = $0; sub(/^[^:]*:[^:]*:/, "", t)
      while (match(t, /process\.env\.[A-Z_][A-Z0-9_]*/)) { print substr(t, RSTART + 12, RLENGTH - 12) "\t" src; t = substr(t, RSTART + RLENGTH) }
      while (match(t, /(Getenv|LookupEnv|getenv|environ\.get|environ\[|GetEnvironmentVariable|env\[)\(?["\047][A-Za-z0-9_]+["\047]/)) {
        s = substr(t, RSTART, RLENGTH); sub(/^[^"\047]*["\047]/, "", s); sub(/["\047]$/, "", s); print s "\t" src; t = substr(t, RSTART + RLENGTH)
      }
    }' | sort -u > "$TMP/d.tsv"
if [ -s "$TMP/d.tsv" ]; then
  echo "| Variable | Source |"
  echo "|---|---|"
  awk -F'\t' '{ printf "| `%s` | `%s` |\n", $1, $2 }' "$TMP/d.tsv"
else
  echo "None found."
fi
echo

# ---- E ----
echo "## E. .env.example cross-check"
ENVEX="$(ffind "$TARGET" -name ".env.example" -o -name ".env.sample" -o -name ".env.template" -o -name "example.env")"
if [ -n "$ENVEX" ]; then
  ( cd "$TARGET" && for f in $ENVEX; do grep -E '^[[:space:]]*(export[[:space:]]+)?[A-Za-z_][A-Za-z0-9_]*=' "$f" | sed -E 's/^[[:space:]]*(export[[:space:]]+)?//; s/=.*//'; done ) | sort -u > "$TMP/e.txt"
  { cut -f1 "$TMP/a.tsv"; cut -f1 "$TMP/d.tsv"; awk -F'`' '{ print $6 }' "$TMP/b.md"; } | sort -u > "$TMP/code.txt"
  echo "Files: $(printf '%s ' $ENVEX)"
  echo
  echo "In .env.example but not referenced in code (possibly dead config):"
  comm -23 "$TMP/e.txt" "$TMP/code.txt" | sed 's/^/- `/; s/$/`/' | grep . || echo "- none"
  echo
  echo "Referenced in code/config but missing from .env.example (undocumented):"
  comm -13 "$TMP/e.txt" "$TMP/code.txt" | grep -E '^[A-Z][A-Z0-9_]*$' | sed 's/^/- `/; s/$/`/' | grep . || echo "- none"
else
  echo "No .env.example found."
fi
