#!/usr/bin/env bash
# Candidate endpoint table extracted from source (grep/awk, no build needed).
# Usage: extract-endpoints.sh <target-dir>
# Output: markdown table  Kind | Method | Path | Handler | Source
#   Kind = inbound (served by this service) or outbound-client (declared
#   client interface, e.g. Feign). The agent MUST confirm every row by
#   reading the source line. This is a candidate list, not ground truth.
set -u
. "$(cd "$(dirname "$0")" && pwd)/lib.sh"

TARGET="${1:-}"
[ -d "$TARGET" ] || { echo "usage: extract-endpoints.sh <target-dir>" >&2; exit 64; }

echo "| Kind | Method | Path | Handler | Source |"
echo "|---|---|---|---|---|"

# --- Spring MVC / WebFlux / Feign (Java, Kotlin) -----------------------------
SPRING_FILES="$( (cd "$TARGET" && grep -rlE "${GREP_EXCLUDES[@]}" --include=*.java --include=*.kt -- '@(Get|Post|Put|Patch|Delete|Request)Mapping' . 2>/dev/null) | sed 's|^\./||' | sort)"
for f in $SPRING_FILES; do
  awk -v file="$f" '
    function firstq(s,   m) {           # first "quoted" string in s
      if (match(s, /"[^"]*"/)) return substr(s, RSTART + 1, RLENGTH - 2)
      return ""
    }
    function join(a, b) {
      if (a == "") return (b == "" ? "/" : b)
      if (b == "") return a
      sub(/\/$/, "", a); if (b !~ /^\//) b = "/" b
      return a b
    }
    BEGIN { prefix = ""; kind = "inbound"; inclass = 0; pend = 0 }
    /@FeignClient|@HttpExchange|@RegisterRestClient/ { kind = "outbound-client" }
    # class-level @RequestMapping appears before the class/interface keyword
    !inclass && /@RequestMapping/ { prefix = firstq($0) }
    !inclass && /(class|interface)[ \t]+[A-Za-z0-9_]+/ { inclass = 1 }
    inclass && /@(Get|Post|Put|Patch|Delete|Request)Mapping/ {
      line = $0; m = "ANY"
      if (line ~ /@GetMapping/) m = "GET"; else if (line ~ /@PostMapping/) m = "POST"
      else if (line ~ /@PutMapping/) m = "PUT"; else if (line ~ /@PatchMapping/) m = "PATCH"
      else if (line ~ /@DeleteMapping/) m = "DELETE"
      else if (match(line, /RequestMethod\.[A-Z]+/)) m = substr(line, RSTART + 14, RLENGTH - 14)
      seg = line; sub(/.*@(Get|Post|Put|Patch|Delete|Request)Mapping/, "", seg)
      p = (seg ~ /^\(/) ? firstq(seg) : ""
      pm = m; pp = join(prefix, p); pl = NR; pend = 1
      rest = seg; if (rest ~ /^\(/) sub(/^\([^)]*\)/, "", rest)
      if (match(rest, /[A-Za-z0-9_]+[ \t]*\(/)) {        # handler on the same line
        hn = substr(rest, RSTART, RLENGTH); sub(/[ \t]*\($/, "", hn)
        printf "| %s | %s | `%s` | `%s` | `%s:%d` |\n", kind, pm, pp, hn, file, pl
        pend = 0
      }
      next
    }
    pend && /[A-Za-z0-9_]+[ \t]*\(/ && !/^[ \t]*@/ {
      s = $0; sub(/\(.*/, "", s); n = split(s, w, /[ \t]+/); hn = w[n]
      printf "| %s | %s | `%s` | `%s` | `%s:%d` |\n", kind, pm, pp, hn, file, pl
      pend = 0; next
    }
    pend && /^[ \t]*@/ { next }
  ' "$TARGET/$f"
done

# --- One-line style frameworks (path = first quoted string on the line) ------
emit_generic() {   # $1 kind-label  $2 ERE  $3.. include globs
  local label="$1" re="$2"; shift 2
  local inc=(); for g in "$@"; do inc+=("--include=$g"); done
  ( cd "$TARGET" && grep -rnE "${GREP_EXCLUDES[@]}" "${inc[@]}" -- "$re" . 2>/dev/null ) | sed 's|^\./||' |
  awk -v label="$label" '
    {
      split($0, parts, ":"); file = parts[1]; ln = parts[2]
      text = $0; sub(/^[^:]*:[^:]*:/, "", text)
      m = "ANY"
      if (match(toupper(text), /(GET|POST|PUT|PATCH|DELETE)[^A-Z]/)) m = substr(toupper(text), RSTART, RLENGTH - 1)
      p = ""
      if (match(text, /["\047`][^"\047`]*["\047`]/)) p = substr(text, RSTART + 1, RLENGTH - 2)
      printf "| inbound | %s | `%s` | (%s) | `%s:%s` |\n", m, (p == "" ? "?" : p), label, file, ln
    }'
}

emit_generic "nestjs"  '@(Get|Post|Put|Patch|Delete)\(' '*.ts'
emit_generic "express" '(router|app|server|fastify)\.(get|post|put|patch|delete)\(' '*.ts' '*.js' '*.mjs' '*.cjs'
emit_generic "go"      '(HandleFunc|Handle)\("|\.(GET|POST|PUT|PATCH|DELETE)\("|\.(Get|Post|Put|Patch|Delete)\("' '*.go'
emit_generic "python"  '@(app|router|bp|blueprint|api)\.(get|post|put|patch|delete|route)\(' '*.py'
emit_generic "jaxrs"   '@Path\("' '*.java' '*.kt'
emit_generic "aspnet"  '\[Http(Get|Post|Put|Patch|Delete)|Map(Get|Post|Put|Patch|Delete)\("' '*.cs'

# NestJS controller prefixes (to combine with @Get paths manually)
NEST="$( (cd "$TARGET" && grep -rnE "${GREP_EXCLUDES[@]}" --include=*.ts -- "@Controller\(" . 2>/dev/null) | sed 's|^\./||')"
if [ -n "$NEST" ]; then
  echo
  echo "NestJS controller prefixes (prepend to @Get/@Post paths in the same file):"
  printf '%s\n' "$NEST" | trim_line
fi

echo
echo "Specs found (cross-check only):"
ffind "$TARGET" -name "openapi*.y*ml" -o -name "openapi*.json" -o -name "swagger*.y*ml" -o -name "swagger*.json" -o -name "*.proto" -o -name "*.graphqls" -o -name "*.graphql" | sed 's/^/- /'
