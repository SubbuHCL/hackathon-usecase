# Facts file format

Facts files live in `{TARGET}/docs/.docgen/facts/`. They are the only input
the writer uses, so the docs can be regenerated without re-reading code.

## Rules

1. One file per phase: `01-stack.md`, `02-api.md`, `03-data.md`,
   `04-events.md`, `05-config.md`, `06-outbound.md`, `07-runtime.md`,
   `08-deployment.md`.
2. Every fact ends with its evidence in backticks: `` `path/to/File.java:42` ``.
   For a fact spanning lines, use `` `File.java:42-58` ``.
3. Use `not found in source` for gaps. Use `inferred:` as a prefix for any
   statement that is your interpretation rather than a literal code fact
   (for example, business purpose).
4. Keep it terse: bullets and tables, no prose paragraphs.
5. Header block on every file:

```markdown
# Facts: <phase name>
- phase: <NN>
- status: complete | partial | skipped
- graph: used | not used
- files read: <count>
```

## Example: 02-api.md

```markdown
# Facts: API
- phase: 02
- status: complete
- graph: used
- files read: 3

## Summary
- base path: `/api/v1` `OrderController.java:7`
- auth: none found (no security annotations, no SecurityFilterChain) `find-code security: 0`

## Endpoints

### POST /api/v1/orders
- handler: `OrderController.create` `OrderController.java:11-12`
- body: `Order` (fields: id Long, sku String NOT NULL, status String) `Order.java:6-9`
- responses: 201 `Order` `OrderController.java:12`
- call chain: create → OrderService.createOrder → InventoryClient.reserve, OrderRepository.save, kafka.send("order.created") `OrderService.java:13`
- blast radius: HIGH. Rationale: transactional write plus an event and an outbound call. `OrderService.java:12-13`
  - mutates: yes
  - downstream consumers: none identified
  - side effects: publishes `order.created`; calls inventory-service `POST /api/v1/reservations/{sku}`

### GET /api/v1/orders/{id}
- handler: `OrderController.get` `OrderController.java:13-14`
- params: id (path, Long, required)
- responses: 200 `Order`; on a missing id, `orElseThrow()` raises NoSuchElementException. Status: inferred: 500 (no exception handler found) `OrderService.java:14`
- blast radius: LOW. Rationale: read-only, no known consumers.

## Spec discrepancies
- no spec present
```

## Example: 05-config.md row format

```markdown
| Variable | Default | Required | Property key | Purpose | Source |
|---|---|---|---|---|---|
| `DATABASE_URL` | `jdbc:postgresql://localhost:5432/orders` | No | `spring.datasource.url` | primary DB connection | `application.yml:5` |
| `DB_PASSWORD` | - | Yes | `spring.datasource.password` | DB password (secret) | `application.yml:6` |
```

After phase 8, add a `Delivery source` column with values `literal`,
`ConfigMap:<name>`, `Secret:<name>` or `ExternalSecret:<store>`, taken from
`08-deployment.md`.
