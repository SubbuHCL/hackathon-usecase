# Phase playbooks by stack

Read only the section for the detected stack. Every section follows the
phase numbers used in `SKILL.md`.

---

## A. Java / Kotlin (Spring Boot, Ktor, Quarkus, Micronaut)

### Phase 1: Stack
- `view_file pom.xml` (or `build.gradle(.kts)`): read `<parent>`,
  `<properties>`, `<dependencies>` and `<dependencyManagement>`.
- Kotlin indicators: `build.gradle.kts`, the `kotlin(` plugin, `.kt` sources.
- Starter meanings:
  - `starter-web`: Tomcat/REST
  - `starter-webflux`: Netty/reactive
  - `data-jpa`: Hibernate
  - `data-mongodb`, `data-redis`
  - `security`
  - `actuator`: `/actuator/health`
  - `spring-kafka`, `spring-rabbit`
  - `openfeign`: declarative clients
  - `io.ktor:ktor-server-*`: Ktor
- Versions marked "managed" come from the Spring Boot BOM or the parent POM.

### Phase 2: API
- Controllers: `@RestController`, or `@Controller` + `@ResponseBody`.
- Full path = class `@RequestMapping` + method mapping (the extractor resolves this).
- Per method, read: `@RequestBody`, `@PathVariable`, `@RequestParam`,
  `@RequestHeader`, the return type (`ResponseEntity<T>`, `Mono<T>`,
  `Flux<T>`), `@ResponseStatus`, `@Valid` / `@Validated` with DTO constraint
  annotations, and `@PreAuthorize` / `@Secured` / `@RolesAllowed`.
- Error mapping: `@ControllerAdvice` / `@ExceptionHandler` classes define the
  4xx/5xx bodies. Find them with `find-code.sh <target> controllers`, then
  `grep_search ExceptionHandler`.
- DTOs: read each request and response class. Records and Lombok `@Data` mean
  the fields are the properties.
- Ktor: `routing { get("/x") { ... } }` blocks; read the route files in full.
- WebFlux functional routes: `RouterFunctions.route()` / `coRouter { }`.

### Phase 3: Data
- `@Entity` / `@Table(name=)` (the table name defaults to the class name in
  snake_case if absent), `@Id` + `@GeneratedValue`, `@Column(nullable,
  unique, length)`, `@Enumerated`, `@Version` (optimistic locking).
- Relationships: `@OneToMany(mappedBy)`, `@ManyToOne` + `@JoinColumn`,
  `@ManyToMany` + `@JoinTable`, and the `fetch` type.
- Mongo: `@Document(collection=)`, `@Field`, `@DBRef`.
- Repositories: derived query names (`findByStatusAndCreatedAtAfter`),
  `@Query`, `@Modifying`.
- Migrations: Flyway `db/migration/V<n>__*.sql`. Read the newest 10 files and
  the first one. Liquibase: changelog `createTable`/`addColumn`. Migrations
  hold the constraints (FKs, indexes) that entities may not show.
- Lifecycle states: an enum `status` field plus the service methods that set
  it. Draw a state diagram only if the transitions are visible in code.

### Phase 4: Events
- Consumers: `@KafkaListener(topics=, groupId=)`, `@RabbitListener(queues=)`,
  `@JmsListener`, `@SqsListener`, Spring Cloud Stream functional beans
  (`Consumer<T>` / `Function<T,R>` `@Bean` plus `spring.cloud.stream.bindings.*`
  in YAML), `@EventListener` / `@TransactionalEventListener` (in-process
  events; document them separately from broker topics).
- Producers: `kafkaTemplate.send("topic", key, payload)`,
  `rabbitTemplate.convertAndSend(exchange, routingKey, msg)`,
  `streamBridge.send("binding", msg)`, `applicationEventPublisher.publishEvent(e)`.
- Topic names may be constants or `${...}` properties. Resolve them via
  `extract-config.sh`.
- Payload: the listener parameter type or the send() argument type. Read that class.

### Phase 5: Config
- `extract-config.sh` covers `${VAR:default}` in YAML and properties, `@Value`,
  `@FeignClient(url=)`, and `@ConfigurationProperties` prefixes.
- Read each `@ConfigurationProperties` class: fields map to `prefix.field`
  (env var `PREFIX_FIELD`, via relaxed binding).
- Profiles: `application-<profile>.yml`. Note which values each profile overrides.
- Secrets: password, secret, key and token properties count as secrets.
  Never print their real values.

### Phase 6: Outbound
- `@FeignClient(name=, url=)` interfaces (the extractor lists them as
  `outbound-client` routes).
- `WebClient.builder().baseUrl(...)`, `RestTemplate`, `RestClient`: find the
  base URL property and the calling methods.
- Resilience: `@CircuitBreaker`, `@Retry`, `@TimeLimiter` (resilience4j).
  Note them per client.

### Phase 7: Runtime
- Dockerfile: base image, build stage, `EXPOSE`, `ENTRYPOINT`, JVM flags.
- `mvnw` / `gradlew`: use the wrapper in RUNBOOK commands.
- Artifact: `target/<artifactId>-<version>.jar` or `build/libs/*.jar`
  (check `bootJar { archiveFileName }`).
- Health: actuator `/actuator/health` when actuator is present. Check
  `management.endpoints.web.base-path` and `management.server.port`.

---

## B. Node.js / TypeScript (NestJS, Express, Fastify)

- **Stack**: from `package.json`, read `dependencies`, `devDependencies`,
  `scripts` and `engines.node`; also `.nvmrc` and `tsconfig.json`.
- **API**:
  - NestJS: `@Controller('prefix')` plus `@Get(':id')` etc.;
    DTOs use `class-validator` decorators; guards use `@UseGuards`.
  - Express/Fastify: `router.<verb>(path, ...middlewares, handler)`, mounted
    with `app.use('/prefix', router)`. Find the `app.use` lines to build full paths.
  - GraphQL: `@Resolver`, `@Query`, `@Mutation`, or the schema `.graphql` files.
- **Data**: Prisma `schema.prisma` (models, relations, `@@map`), TypeORM
  `@Entity`, Mongoose `new Schema({...})`, migrations in `prisma/migrations`
  or `src/migrations`.
- **Events**: KafkaJS `consumer.subscribe({ topic })` and `producer.send({ topic })`;
  NestJS microservices `@EventPattern` / `@MessagePattern`.
- **Config**: `process.env.X`, `@nestjs/config` `ConfigService.get('X')`, `.env.example`.
- **Outbound**: `axios.create({ baseURL })`, `HttpService`, `fetch(`.
- **Runtime**: the `npm run` scripts (`dev`, `start`, `build`), Dockerfile, compose.

## C. Go (net/http, Gin, Echo, Chi, gRPC)

- **Stack**: `go.mod` (module path, Go version, requires).
- **API**: `http.HandleFunc`, `mux.Handle`, `r.GET(...)` (Gin), `e.GET` (Echo),
  `r.Get` (Chi), and route groups (`r.Group("/api")`). gRPC: `.proto` files
  plus `Register<Svc>Server`.
- **Data**: GORM models (`gorm.Model`, struct tags), `sqlc` queries, and
  `migrations/*.sql` (golang-migrate).
- **Events**: `sarama`, `segmentio/kafka-go`, `franz-go` readers and writers; NATS `Subscribe`.
- **Config**: `os.Getenv`, `os.LookupEnv`, `envconfig` / `viper` struct tags.
- **Runtime**: `Makefile` targets, `cmd/<app>/main.go`.

## D. Python (FastAPI, Flask, Django)

- **Stack**: `pyproject.toml` / `requirements.txt`.
- **API**: FastAPI `@app.get` / `APIRouter(prefix=)` with Pydantic models;
  Flask `@app.route(methods=)` / Blueprints with `url_prefix`; Django
  `urls.py` plus DRF ViewSets and routers.
- **Data**: SQLAlchemy models (`__tablename__`), Django `models.Model`, Alembic `versions/`.
- **Events**: `confluent_kafka` / `aiokafka`; Celery tasks (`@app.task`, `@shared_task`).
- **Config**: `os.environ`, `os.getenv`, Pydantic `BaseSettings` fields
  (env name = field name, uppercased, plus `env_prefix`).

## E. .NET (ASP.NET Core)

- **Stack**: `*.csproj` `TargetFramework` and `PackageReference`.
- **API**: `[ApiController]`, `[Route("api/[controller]")]`, `[HttpGet("{id}")]`;
  minimal APIs `app.MapGet("/x", ...)`; `[Authorize]`.
- **Data**: EF Core `DbContext` `DbSet<T>`, entity configurations, `Migrations/`.
- **Config**: `appsettings*.json`, `IConfiguration["Section:Key"]` (env var
  `Section__Key`), `IOptions<T>`.
