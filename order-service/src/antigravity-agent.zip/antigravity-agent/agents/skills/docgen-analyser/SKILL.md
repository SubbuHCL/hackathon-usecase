---
name: docgen-analyser
description: Code-first analysis procedure for service documentation. Detects repo shape and tech stack, then extracts API endpoints with blast radius, data model, events, configuration, outbound dependencies and runtime facts into evidence-backed facts files. Use during docgen Step 3 (inventory) and Step 4 (analysis), or whenever you must derive service facts from source code.
---

# DocGen Analyser

Principle: **read the code, record facts with evidence, and never guess.**
Spec files (OpenAPI, `.env.example`) are cross-checks only.

`{SKILLS}` is the skills folder and `{TARGET}` is the directory being
documented (both resolved in docgen Step 0). `{D}` is `{TARGET}/docs/.docgen`.

## Scripts (in `scripts/`)

| Script | Purpose |
|---|---|
| `preflight.sh <target>` | Checks the required and optional tools |
| `inventory.sh <target> [--quick]` | Repo shape, stack, candidate counts, deployment families, and phase suggestions. Writes `{D}/inventory.md` |
| `find-code.sh <target> <category> [--count]` | Grep fallback that lists candidate lines. Categories: `entrypoints controllers grpc graphql entities repositories migrations consumers producers clients config security scheduled tests all` |
| `extract-endpoints.sh <target>` | Candidate endpoint table (inbound and outbound-client), with class-level prefixes resolved |
| `extract-config.sh <target>` | Env vars, defaults, `@Value` keys, `@ConfigurationProperties`, direct env reads, and the `.env.example` cross-check |

Every script output is a **candidate list**. Confirm each fact by reading the
cited line before you record it.

## Phase applicability

Use `{D}/inventory.md` → "Suggested phase applicability", overridden by the
user's answers. A skipped phase means its doc is skipped too. `README.md`,
`DEPENDENCIES.md`, `CONFIGURATION.md` and `ARCHITECTURE.md` are always
generated.

## Phase procedure

For **every** phase, do the same five things:

1. Run the phase's script (table below).
2. If the knowledge graph is ready, run the graph queries from
   `codegraph-knowledge-graph/references/query-recipes.md`. Otherwise use
   `find-code.sh`.
3. Read the confirming code with `view_file`. Skip files that `explore` or
   `node` already printed in full.
4. Write `{D}/facts/<NN>-<name>.md` in the format given in
   `references/facts-format.md`.
5. Tick the phase in `{D}/state.md`.

| # | Phase | Script | Facts file | What to extract |
|---|---|---|---|---|
| 1 | Tech stack | `inventory.sh` | `01-stack.md` | Language and version, framework and version, build tool and wrapper, entry point, starters and libraries by role, test frameworks |
| 2 | API | `extract-endpoints.sh` and graph `routes` | `02-api.md` | Per endpoint: method, full path, handler, params (path, query, header, body), request and response types, status codes, auth annotations, validation, blast radius |
| 3 | Data model | `find-code.sh entities`, `repositories`, `migrations` | `03-data.md` | Per entity: table or collection, fields (type, constraints), id strategy, relationships, lifecycle states, custom repository queries, migration history |
| 4 | Events | `find-code.sh consumers`, `producers` | `04-events.md` | Per topic or queue: name, direction, consumer group, payload type and fields, trigger, side effects |
| 5 | Configuration | `extract-config.sh` | `05-config.md` | Per variable: name, default, required, property key, purpose, source file; config classes |
| 6 | Outbound deps | `find-code.sh clients` and the outbound-client rows of `extract-endpoints.sh` | `06-outbound.md` | Per downstream: service name, base URL variable, endpoints called, caller methods |
| 7 | Runtime | `inventory.sh` Runtime section | `07-runtime.md` | Dockerfile base image, exposed port, entrypoint; compose services (image, port, purpose); wrapper commands; health endpoint; artifact name |

Phases 8 and 9 (deployment) belong to the **docgen-deployment** skill.

Stack-specific reading guides (Spring/Java/Kotlin, Node/NestJS/Express, Go,
Python, .NET): `references/phase-playbooks.md`. Read only the section for the
stack you detected.

## Blast radius (phase 2)

Rate every endpoint. **When uncertain, choose HIGH.**

| Severity | Rule |
|---|---|
| HIGH | Mutates data (save, update, delete, `@Transactional` write), or sits on an auth, payment or order critical path, or has known downstream consumers |
| MEDIUM | Read-only but used by several consumers, or mutates only non-critical or audit data |
| LOW | Read-only with no known consumers, or internal/admin-only (`/admin/`, admin role) |

Evidence to collect, using the graph when it is ready:
- `callees <handler>`, then `callees <serviceMethod>`: look for repository writes, producer sends, and client calls.
- `impact <serviceMethod> --depth 2`: what else depends on it.
- Internal consumers: client routes with the same path elsewhere in the repo.

Record: severity, a one-sentence rationale, mutates (yes/no), downstream
consumers (or "none identified"), and side effects (events, cache, external calls).

## Spec cross-check

If an OpenAPI, AsyncAPI, proto or GraphQL schema exists, compare it to the
code **after** phase 2 or 4. Record discrepancies in the facts file under
`## Spec discrepancies`: endpoints only in the spec (stale spec) and endpoints
only in the code (undocumented). The code wins.

## Exit checklist (all must be answerable from the facts files)

- [ ] What does the service do, and what does it own?
- [ ] All endpoints, with method, path, shapes and blast radius (or "no API").
- [ ] Every env var, with its default and whether it is required.
- [ ] Every table or collection it owns (or "no persistence").
- [ ] Every topic it produces or consumes (or "no messaging").
- [ ] Every downstream service it calls (or "none").
- [ ] How to build and run it locally.

If an item is unanswerable, read more code. If the code genuinely does not
say (for example, the logic lives in an external library), write
`not found in source: <what and where you looked>`. Never invent an answer.
