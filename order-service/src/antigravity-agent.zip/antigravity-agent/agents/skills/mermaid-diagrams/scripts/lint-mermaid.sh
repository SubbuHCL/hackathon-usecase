#!/usr/bin/env bash
# Offline lint (and optional render check) for ```mermaid blocks in Markdown.
# Usage: lint-mermaid.sh <file.md|dir> [...]
# Render check: uses `mmdc` when on PATH, or `npx -y @mermaid-js/mermaid-cli`
# when DOCGEN_MMDC_NPX=1 (downloads Chromium on first use).
# Exit 0 = no errors (warnings allowed), 1 = errors found, 64 = usage.
# Files under docs/.docgen/ are skipped unless passed explicitly.
set -u

[ $# -ge 1 ] || { echo "usage: lint-mermaid.sh <file.md|dir> [...]" >&2; exit 64; }

FILES=""
for p in "$@"; do
  if [ -d "$p" ]; then
    FILES="$FILES$(find "$p" -name "*.md" -not -path "*/.docgen/*" -type f | sort)
"
  elif [ -f "$p" ]; then
    FILES="$FILES$p
"
  fi
done

MMDC=""
if command -v mmdc >/dev/null 2>&1; then MMDC="mmdc"
elif [ "${DOCGEN_MMDC_NPX:-0}" = "1" ] && command -v npx >/dev/null 2>&1; then MMDC="npx -y @mermaid-js/mermaid-cli"
fi

TMP="$(mktemp -d 2>/dev/null || mktemp -d -t mmdlint)"
trap 'rm -rf "$TMP"' EXIT
ERR=0; BLOCKS=0

while IFS= read -r f; do
  [ -n "$f" ] || continue
  awk -v file="$f" -v tmp="$TMP" '
    function err(msg) { printf "%s:%d: ERROR [%s] %s\n", file, bl, type, msg; errs++ }
    function warn(msg) { printf "%s:%d: WARN  [%s] %s\n", file, bl, type, msg }
    BEGIN { inb = 0; n = 0; errs = 0 }
    /^[ \t]*```mermaid[ \t]*$/ && !inb { inb = 1; bl = NR; n++; type = ""; nodes = 0; out = tmp "/b" n ".mmd"; printf "" > out; next }
    inb && /^[ \t]*```[ \t]*$/ {
      inb = 0; close(out)
      if (type == "") err("empty diagram")
      if (type ~ /^C4/ && nodes > 20) warn(nodes " elements; C4 diagrams should stay under 20")
      if (type == "architecture-beta" && nodes > 25) warn(nodes " nodes; split architecture diagrams above 25")
      print file "\t" bl "\t" out >> (tmp "/index.tsv")
      next
    }
    inb {
      print > out
      line = $0
      if (line ~ /^[ \t]*$/ || line ~ /^[ \t]*%%/) next
      if (type == "") {
        t = line; sub(/^[ \t]+/, "", t); split(t, w, /[ \t]/); type = w[1]
        if (type !~ /^(graph|flowchart|sequenceDiagram|classDiagram|stateDiagram|stateDiagram-v2|erDiagram|journey|gantt|pie|gitGraph|mindmap|timeline|quadrantChart|requirementDiagram|C4Context|C4Container|C4Component|C4Dynamic|C4Deployment|architecture-beta|block-beta|sankey-beta|xychart-beta|packet-beta|kanban|---)$/)
          err("unknown diagram type: " type)
        next
      }
      # unresolved template placeholders such as {service-name} or {ISO-date}
      if (match(line, /\{[a-z][a-z0-9_]*(-[a-z0-9_]+)+\}|\{[A-Z][A-Za-z]+ [^}]*\}|\{ISO-date\}/) && type != "erDiagram")
        err("unresolved template placeholder " substr(line, RSTART, RLENGTH))
      if (match(line, /\{\{[^}]*\}\}/)) err("unfilled template placeholder " substr(line, RSTART, RLENGTH))
      if (index(line, "·") > 0) err("middle dot (U+00B7) is not allowed; use - instead")
      if (type == "architecture-beta") {
        if (line ~ /^[ \t]*(service|group|junction)[ \t]/) nodes++
        if (line ~ /^[ \t]*(service|group)[ \t]/) {
          if (line !~ /^[ \t]*(service|group)[ \t]+[A-Za-z0-9_]+\([^(){}]+\)\[[^][]*\]/) err("expected: service|group <id>(<icon>)[<Label>]  got: " line)
          if (match(line, /\[[^][]*\]/)) {
            lab = substr(line, RSTART + 1, RLENGTH - 2)
            if (lab ~ /[\/{}.]/) err("label [" lab "] contains / { } or . (lexer error); use - or a space")
          }
        } else if (line ~ /-->|<--|--/) {
          if (line !~ /^[ \t]*[A-Za-z0-9_{}]+:[LRTB][ \t]*(<)?--(>)?[ \t]*[LRTB]:[A-Za-z0-9_{}]+[ \t]*$/) err("edge must look like a:R --> L:b  got: " line)
          if (line ~ /--[ \t]*\|/ || line ~ /-->[ \t]*\|/) err("edge labels are not supported in architecture-beta")
        }
      } else if (type == "graph" || type == "flowchart") {
        s = line
        while (match(s, /\[[^]"]*\]/)) {
          lab = substr(s, RSTART + 1, RLENGTH - 2); s = substr(s, RSTART + RLENGTH)
          if (lab ~ /[{}]/) err("unquoted { } inside [...] label; wrap it as [\"...\"]")
          if (lab ~ /^\(/ || lab ~ /\)$/) continue
          if (lab ~ /[()]/ ) warn("parentheses inside an unquoted [...] label; prefer [\"...\"]")
        }
        if (line ~ /-->/ || line ~ /---/ || line ~ /-\.->/ || line ~ /==>/) nodes++
      } else if (type ~ /^C4/) {
        if (line ~ /^[ \t]*(Person|Person_Ext|System|System_Ext|SystemDb|SystemDb_Ext|SystemQueue|SystemQueue_Ext|Container|Container_Ext|ContainerDb|ContainerDb_Ext|ContainerQueue|ContainerQueue_Ext|Component|Component_Ext|ComponentDb|ComponentQueue)\(/) nodes++
        if (line ~ /^[ \t]*BiRel\(/) warn("BiRel is ambiguous; use two Rel() calls")
      } else if (type == "sequenceDiagram") {
        if (line ~ /->>[ \t]*$/) err("message arrow without a target")
      }
    }
    END {
      if (inb) { printf "%s:%d: ERROR unclosed ```mermaid fence\n", file, bl; errs++ }
      printf "%s\t%d\t%d\n", file, n, errs >> (tmp "/summary.tsv")
    }
  ' "$f"
done <<EOF
$FILES
EOF

if [ -f "$TMP/summary.tsv" ]; then
  BLOCKS=$(awk -F'\t' '{ s += $2 } END { print s + 0 }' "$TMP/summary.tsv")
  ERR=$(awk -F'\t' '{ s += $3 } END { print s + 0 }' "$TMP/summary.tsv")
fi

RENDERED="skipped (no mmdc; validate with the Mermaid MCP instead)"
if [ -n "$MMDC" ] && [ -f "$TMP/index.tsv" ]; then
  RFAIL=0; RN=0
  while IFS="$(printf '\t')" read -r file line mmd; do
    RN=$((RN + 1))
    if ! $MMDC -q -i "$mmd" -o "$mmd.svg" >"$mmd.log" 2>&1; then
      echo "$file:$line: ERROR [render] $(grep -iE 'error|parse|expect' "$mmd.log" | head -2 | tr '\n' ' ' | cut -c1-240)"
      RFAIL=$((RFAIL + 1))
    fi
  done < "$TMP/index.tsv"
  ERR=$((ERR + RFAIL))
  RENDERED="$((RN - RFAIL))/$RN rendered with mmdc"
fi

echo "mermaid-lint: $BLOCKS block(s), $ERR error(s); render check: $RENDERED"
[ "$ERR" -eq 0 ] || exit 1
exit 0
