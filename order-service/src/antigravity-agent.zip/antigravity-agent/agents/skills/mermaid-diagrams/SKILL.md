---
name: mermaid-diagrams
description: Authoring and validation rules for Mermaid diagrams in generated docs (flowchart, sequence, ER, state, C4, architecture-beta with cloud icons). Validates every diagram through the Mermaid MCP server when connected, a local mermaid-cli render when installed, and an offline lint that always runs. Use before writing any Mermaid block to a file.
---

# Mermaid Diagrams

**No diagram reaches a final doc without passing validation.**

## 1. Discover what's available (once per run)

1. **Mermaid MCP** (`mermaid` server in `.agents/mcp_config.json`, at
   `https://mcp.mermaid.ai/mcp`, which requires a free Mermaid sign-in via
   OAuth). If the server is connected, call its `list_tools` tool once and
   record the tool names in `state.md`. Known tools:
   - `validate_and_render_mermaid_diagram`: validate and render (documented)
   - `list_tools` (documented)
   - an icon-search tool and a syntax-document tool, **if** the server
     lists them (for example, names containing `icon` or `syntax`). Use them
     only if they appear in `list_tools`. Do not call tools that are not listed.
2. **Local renderer**: `mmdc` on PATH, or `DOCGEN_MMDC_NPX=1` with `npx`.
   `lint-mermaid.sh` uses it automatically.
3. **Offline lint**: `scripts/lint-mermaid.sh`. Always available.

Record the result as `mermaid: mcp | mmdc | lint-only` in `state.md`.

## 2. Validation loop (per diagram)

1. Write the diagram following `references/syntax-safety.md` (and, for C4,
   the **c4-architecture** skill).
2. If the MCP is available, call `validate_and_render_mermaid_diagram` with
   the diagram code.
3. Run the lint on the draft file:
   `bash {SKILLS}/mermaid-diagrams/scripts/lint-mermaid.sh {TARGET}/docs/.docgen/draft/<FILE>.md`
4. On any error, fix the diagram using the error message, then repeat from
   step 2. **Maximum 3 attempts.**
5. If it still fails after 3 attempts:
   - flowchart-like content: simplify to a plain `graph TB`.
   - `architecture-beta`: replace brand icons with the built-in shapes
     (`cloud`, `server`, `database`, `disk`, `internet`). If it still fails,
     use the `graph TB` fallback.
   - Otherwise keep the block and put
     `<!-- TODO(docgen): diagram could not be validated: <error> -->` directly
     above it.

## 3. Choosing the diagram type

| Need | Type |
|---|---|
| System context, containers, components | C4 (`C4Context`, `C4Container`, `C4Component`) via the c4-architecture skill |
| Request flow with 3 or more participants | `sequenceDiagram` |
| Entities and relations (2 or more related entities) | `erDiagram` |
| Lifecycle of a status field | `stateDiagram-v2` |
| Pub/sub topology | `graph LR` with stadium nodes `(["topic"])` |
| Cloud deployment with vendor icons | `architecture-beta` (+ a `graph TB` fallback) |
| k8s logical deployment | `C4Deployment` |

## 4. Icons in architecture-beta

- Use brand icons (`aws:...`, `azure:...`, `gcp:...`, `logos:...`) only when
  an icon-search tool returned the id, or when the MCP render succeeded with it.
- Otherwise use the built-in shapes `cloud`, `server`, `database`, `disk`,
  `internet`.
- **Renderer caveat**: brand-icon packs render on mermaid.ai and in tools
  that register Iconify packs. GitHub and many Markdown viewers don't, and
  show blank icons. That's why DEPLOYMENT.md always keeps a `graph TB`
  fallback below the icon diagram.

See `docgen-deployment/references/icon-catalog.md` for the search queries.
