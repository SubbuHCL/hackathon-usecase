# Mermaid syntax safety rules

These are the failure modes the lint checks for, plus the correct patterns.

## Forbidden characters

| Character | Where | Problem | Use instead |
|---|---|---|---|
| `·` (U+00B7 middle dot) | any label | lexer error | `-` or a space |
| `/` | architecture-beta `[Label]` | lexer error | `or`, `-` |
| `.` | architecture-beta `[Label]` | lexer error in some versions | `-` or a space (`order-created`, not `order.created`) |
| `{` `}` | architecture-beta `(icon)` or `[Label]` | parsed as an edge modifier | remove them |
| `{` `}` | flowchart `[...]` unquoted | parsed as a rhombus shape | quote it: `["Ingress {host}"]` |
| nested `[` `]` | any `[Label]` | ends the label early | rephrase |
| template placeholders like `{service-name}` | anywhere | not real content | substitute the real value |

## architecture-beta

```
architecture-beta
    group <id>(<icon>)[<Label>]
    group <id>(<icon>)[<Label>] in <parentGroupId>
    service <id>(<icon>)[<Label>] in <groupId>
    junction <id> in <groupId>
    <id>:<R|L|T|B> --> <R|L|T|B>:<id>
```

- Every `service` and `group` has an icon: a built-in (`cloud`, `server`,
  `database`, `disk`, `internet`) or a resolved brand icon.
- Ids are `[A-Za-z0-9_]` only.
- **No edge labels.** Put the protocol in the node label instead
  (`[Service ClusterIP 8080]`), or in the `graph TB` fallback.
- Edges that cross several group boundaries can fail to render. Route them
  through a `junction` in the shared parent group.
- Nest groups to mirror reality: internet, cloud, network, cluster,
  namespace. Use 25 nodes or fewer per diagram.

## flowchart / graph

```mermaid
graph LR
  client["Client"] -->|"HTTPS 443"| ing["Ingress<br/>orders.example.com"]
  ing --> svc["order-service"]
  svc -->|JDBC| db[("orders DB<br/>PostgreSQL")]
  svc -->|produces| t1(["order.created"])
```

- Quote any label that contains spaces, punctuation, `<br/>` or braces.
- Node ids have no spaces. Labels go in brackets.
- Shapes: `[rect]`, `(["stadium/topic"])`, `[("cylinder/db")]`, `[[subroutine]]`, `{rhombus}` (only for decisions).

## sequenceDiagram

```mermaid
sequenceDiagram
  participant C as Client
  participant S as OrderService
  C->>S: POST /api/v1/orders
  S-->>C: 201 Created
```

- Declare participants with aliases. Every arrow needs a target and a message.
- Use `-->>` for replies and `->>` for calls. Use `Note over A,B: text` for annotations.
- `alt`, `opt` and `loop` blocks must close with `end`.

## erDiagram

```mermaid
erDiagram
  ORDERS {
    bigint id PK
    varchar sku "NOT NULL"
    varchar status
  }
  CUSTOMERS ||--o{ ORDERS : places
```

- Attribute lines are `<type> <name> [PK|FK|UK] ["comment"]`. Types have no spaces (`varchar`, not `varchar(64)`).
- Cardinality: `||--||`, `||--o{`, `}o--o{`, `|o--||`.

## stateDiagram-v2

```mermaid
stateDiagram-v2
  [*] --> PENDING
  PENDING --> CONFIRMED : confirm()
  CONFIRMED --> [*]
```

Draw it only when the transitions are visible in code (a method sets the next state).

## C4

See the **c4-architecture** skill. Key points: the first line is the
diagram type, then `title`; every element has a description; there are 20
elements or fewer; use `Rel` and not `BiRel`.
