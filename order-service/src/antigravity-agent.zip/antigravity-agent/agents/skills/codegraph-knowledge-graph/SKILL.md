---
name: codegraph-knowledge-graph
description: Builds and queries a local CodeGraph knowledge graph (symbols, call paths, routes, impact) of a codebase using the codegraph CLI. Use before documenting, analysing, or exploring a repository, and whenever you need to find where a symbol is defined, who calls it, what it calls, or which HTTP routes exist.
---

# CodeGraph Knowledge Graph

CodeGraph (`@colbymchenry/codegraph`) parses the repository with Tree-sitter
and stores symbols and relationships in a local SQLite graph at
`{TARGET}/.codegraph/codegraph.db`. Nothing leaves the machine. Java, Kotlin,
TypeScript/JavaScript, Go, Python, C#, Rust, PHP, Ruby, Scala and Terraform
are supported.

Use the graph for structure (where, who calls, what depends). Use
`view_file` to read the exact code you will document.

## 1. Build or refresh the graph

```bash
bash {SKILLS}/codegraph-knowledge-graph/scripts/ensure-graph.sh {TARGET}
```

| Exit | Meaning | What to do |
|---|---|---|
| 0 | `STATUS: ready`. The graph was built (`codegraph init`) or synced (`codegraph sync`). | Continue. Record the node and edge counts in `state.md`. |
| 2 | `STATUS: not-installed` | Show the user the printed install command. Ask whether to install it now or continue without the graph. STOP. |
| 1 | `STATUS: failed (...)` | Record the reason. Continue with grep fallbacks. Retry at most once. |

Notes:
- Indexing is fast (seconds for small repos, a few minutes for very large
  monorepos). If the command times out, run it again; `sync` resumes.
- The script prints a NOTE when `.codegraph/` is not git-ignored. Pass the
  suggestion on to the user in the final report. Do not edit `.gitignore`.
- For a monorepo, index the repository root once, not each service. Then
  scope your queries by path.

## 2. Query the graph (CLI, always works)

Always go through the wrapper. It runs from `{TARGET}`, strips colour codes,
and caps output at 300 lines.

```bash
bash {SKILLS}/codegraph-knowledge-graph/scripts/graph-query.sh {TARGET} <subcommand> [args]
```

| Question | Subcommand |
|---|---|
| Show the relevant code and call paths for a topic | `explore "<symbols or question>"` |
| Show one symbol's source and callers, or a whole file with line numbers | `node <Symbol or path/to/file>` |
| Find symbols by name | `query <name> [--kind class\|method\|function\|interface\|route] [--limit N]` |
| Who calls X? | `callers <symbol> [--limit N]` |
| What does X call? | `callees <symbol> [--limit N]` |
| What breaks if X changes? (blast radius) | `impact <symbol> [--depth 2]` |
| Every HTTP route node (docgen shortcut) | `routes` |
| Index health | `status` |

Rules for efficient use:
1. Start with `explore` for a topic. One explore call often replaces 5 to 10
   file reads, because it returns verbatim, line-numbered source.
2. Do not re-read a file with `view_file` if `explore` or `node` already
   printed it in full.
3. Put concrete symbol names in the query (`"OrderController OrderService
   createOrder"`), not vague prose.
4. `routes` returns both inbound handlers and outbound declarative clients
   (such as Feign interfaces). Classify each route by checking the file for
   `@FeignClient`, `@RestController`, and similar annotations.
5. If output is truncated, narrow the query. Do not raise the cap above 600.

## 3. MCP tool (optional)

`.agents/mcp_config.json` registers `codegraph serve --mcp`, which exposes the
`codegraph_explore` tool (plus `codegraph_node`, `codegraph_search`,
`codegraph_callers`, `codegraph_callees` and `codegraph_impact`, enabled via
`CODEGRAPH_MCP_TOOLS`). The MCP server only exposes tools when `.codegraph/`
already existed when the session started. If you just built the index in
this session, use the CLI wrapper above. It returns the same output.

## 4. Per-phase query recipes

See `references/query-recipes.md` for the exact queries to run in each
docgen phase (API, data model, events, config, outbound dependencies), with
the grep fallback for each one.

## 5. When the graph is unavailable

Every recipe has a grep fallback. Use `grep_search` or the docgen-analyser
scripts. Say in the final report that the knowledge graph was not used, and
that call-path facts (blast radius, downstream consumers) are lower
confidence as a result.
