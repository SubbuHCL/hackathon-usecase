#!/usr/bin/env bash
# Run a CodeGraph query from inside the target directory, with ANSI colours
# stripped and output capped so it stays cheap to read.
#
# Usage: graph-query.sh <target-dir> <subcommand> [args...]
#   graph-query.sh . explore "OrderController createOrder"
#   graph-query.sh . node src/main/java/.../OrderService.java
#   graph-query.sh . query OrderService --limit 10
#   graph-query.sh . query Order --kind class --limit 30
#   graph-query.sh . callers saveOrder --limit 20
#   graph-query.sh . callees createOrder --limit 20
#   graph-query.sh . impact OrderRepository --depth 2
#   graph-query.sh . routes        # docgen shortcut: every HTTP route node
# Set DOCGEN_MAX_LINES to change the output cap (default 300).
set -u

if [ $# -lt 2 ]; then
  echo "usage: graph-query.sh <target-dir> <subcommand> [args...]" >&2
  exit 64
fi

TARGET="$1"; shift
MAX="${DOCGEN_MAX_LINES:-300}"
ESC="$(printf '\033')"

command -v codegraph >/dev/null 2>&1 || { echo "codegraph not installed; use the grep fallback." >&2; exit 2; }
cd "$TARGET" 2>/dev/null || { echo "cannot cd into $TARGET" >&2; exit 1; }
[ -d .codegraph ] || { echo "no .codegraph/ index in $TARGET; run ensure-graph.sh first." >&2; exit 3; }

strip() { sed "s/${ESC}\[[0-9;]*[A-Za-z]//g"; }

if [ "$1" = "routes" ]; then
  # Route nodes come from inbound handlers AND outbound declarative clients
  # (e.g. Feign interfaces). The agent must classify each by reading the file.
  echo "# Route nodes (method path -> file:line)"
  for verb in GET POST PUT PATCH DELETE HEAD OPTIONS; do
    codegraph query "$verb" --kind route --limit 500 2>/dev/null | strip | awk '
      $1 == "route" { name = $2 " " $3; next }
      name != "" && $1 ~ /:[0-9]+$/ { print name "\t" $1; name = "" }'
  done | sort -u
  exit 0
fi

set -o pipefail
OUT="$(codegraph "$@" 2>&1 | strip)"
RC=$?
TOTAL=$(printf '%s\n' "$OUT" | wc -l | tr -d ' ')
printf '%s\n' "$OUT" | head -n "$MAX"
if [ "$TOTAL" -gt "$MAX" ]; then
  echo "... [truncated: showing $MAX of $TOTAL lines; narrow the query or raise DOCGEN_MAX_LINES]"
fi
exit $RC
