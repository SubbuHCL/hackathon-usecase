#!/usr/bin/env bash
# Build or refresh the CodeGraph knowledge graph for a target directory.
# Usage: ensure-graph.sh <target-dir> [--no-index]
# Exit: 0 ready | 1 failed | 2 codegraph not installed | 3 not indexed (--no-index)
set -u
ESC="$(printf '\033')"
strip() { sed "s/${ESC}\[[0-9;]*[A-Za-z]//g"; }

TARGET="${1:-.}"
NO_INDEX="${2:-}"

if ! command -v codegraph >/dev/null 2>&1; then
  echo "STATUS: not-installed"
  echo "CodeGraph CLI was not found on PATH. Install it with one of:"
  echo "  npm i -g @colbymchenry/codegraph"
  echo "  curl -fsSL https://raw.githubusercontent.com/colbymchenry/codegraph/main/install.sh | sh"
  echo "Then open a new terminal (the installer updates PATH for new shells only)."
  exit 2
fi

if ! cd "$TARGET" 2>/dev/null; then
  echo "STATUS: failed (cannot cd into $TARGET)"
  exit 1
fi

echo "codegraph: $(codegraph --version 2>/dev/null | head -1)"

if [ -d .codegraph ]; then
  echo "Existing index found in $(pwd)/.codegraph; syncing incrementally..."
  if ! codegraph sync . --quiet; then
    echo "Incremental sync failed; rebuilding the index from scratch..."
    codegraph index . --force --quiet || { echo "STATUS: failed (index --force)"; exit 1; }
  fi
else
  if [ "$NO_INDEX" = "--no-index" ]; then
    echo "STATUS: not-indexed"
    exit 3
  fi
  echo "No index found. Building the knowledge graph (codegraph init)..."
  echo "Large repositories can take a few minutes."
  codegraph init . </dev/null 2>&1 | strip | grep -E "Indexed|nodes|Done|rror" ; [ "${PIPESTATUS[0]}" -eq 0 ] || { echo "STATUS: failed (init)"; exit 1; }
fi

if [ ! -d .codegraph ]; then
  echo "STATUS: failed (.codegraph/ was not created)"
  exit 1
fi

echo "--- codegraph status ---"
codegraph status . 2>&1 | strip | grep -v "^[[:space:]]*$" | head -40

if command -v git >/dev/null 2>&1 && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  if ! git check-ignore -q .codegraph 2>/dev/null; then
    echo "NOTE: .codegraph/ is not git-ignored. Suggest to the user (do not edit .gitignore yourself): add '.codegraph/' to .gitignore."
  fi
fi

echo "STATUS: ready"
exit 0
