# CodeGraph query recipes per docgen phase

`Q` below means:
`bash {SKILLS}/codegraph-knowledge-graph/scripts/graph-query.sh {TARGET}`

`FC <category>` below means the grep fallback:
`bash {SKILLS}/docgen-analyser/scripts/find-code.sh {TARGET} <category>`

Each recipe lists the graph query first and the grep fallback second. Always
confirm a fact by reading the cited lines before you write it to a facts file.

---

## Phase 1: Tech stack and entry point

| Goal | Graph | Fallback |
|---|---|---|
| Entry point | `Q query Application --kind class --limit 10` | `FC entrypoints` |
| Module layout | `Q status` (Files by Language) | `inventory.sh` language counts |

## Phase 2: API endpoints

| Goal | Graph | Fallback |
|---|---|---|
| All routes | `Q routes` | `bash {SKILLS}/docgen-analyser/scripts/extract-endpoints.sh {TARGET}` |
| Handler and its call chain | `Q explore "<Controller> <handlerMethod>"` | `view_file` on the controller, then follow imports |
| Downstream of a handler (repo, client, producer) | `Q callees <handlerMethod> --limit 30` and then `Q callees <serviceMethod>` | `view_file` on the service class; look for repository, client and send/publish calls |
| Who calls this service's endpoints (internal consumers) | `Q query <path-fragment> --kind route --limit 50` (look for client routes with the same path) | `FC clients`, then search the matches for the same path |
| Blast radius of a handler | `Q impact <serviceMethod> --depth 2` | read the call chain manually |

Blast-radius signals to look for in the callees output:
- `save`, `delete`, `update`, `insert`, `persist`, or `@Transactional` means it mutates data.
- `KafkaTemplate.send`, `publishEvent`, or `producer.send` means it has async side effects.
- A Feign or WebClient call means it has an outbound dependency.

## Phase 3: Data model

| Goal | Graph | Fallback |
|---|---|---|
| Entities | `Q explore "@Entity @Table @Document entity classes"` then `Q node <EntityClass>` | `FC entities` |
| Repositories | `Q query Repository --kind interface --limit 50` | `FC repositories` |
| Who writes an entity | `Q callers save --limit 50` then filter by repository | `grep_search` for `.save(` |
| Relationships | `Q node <EntityClass>` (read `@OneToMany`, `@ManyToOne` fields) | `view_file` on the entity |

## Phase 4: Events and messaging

| Goal | Graph | Fallback |
|---|---|---|
| Consumers | `Q explore "KafkaListener RabbitListener EventListener SqsListener consumer"` | `FC consumers` |
| Producers | `Q query KafkaTemplate --limit 20` then `Q callers send --limit 50` | `FC producers` |
| Payload type | `Q node <PayloadClass>` | `view_file` on the class |

## Phase 5: Configuration

| Goal | Graph | Fallback |
|---|---|---|
| `@ConfigurationProperties` classes | `Q explore "ConfigurationProperties properties class"` | `FC config` and `extract-config.sh` |
| Where a property is used | `Q query <fieldName> --kind field --limit 20` | `grep_search` for the property key |

The graph does not parse `${ENV:default}` placeholders in YAML, so always run
`bash {SKILLS}/docgen-analyser/scripts/extract-config.sh {TARGET}` for config.

## Phase 6: Outbound dependencies

| Goal | Graph | Fallback |
|---|---|---|
| Declarative clients | `Q routes` (routes declared in client interfaces) and `Q explore "FeignClient WebClient RestTemplate RestClient HttpClient"` | `FC clients` |
| Who uses a client | `Q callers <clientMethod>` | `grep_search` for the client interface name |

## Phase 8: Deployment

The graph indexes YAML and Terraform as files, but it does not model
deployment topology. Use `docgen-deployment/scripts/discover-deploy.sh` for
deployment discovery.

---

## Budget guide

- A small service (under 50 files) usually needs 1 to 2 explore calls per phase.
- A large service: one explore per controller or aggregate, plus `routes` once.
- If you have made more than 15 graph calls in one phase, stop and write what
  you have to the facts file. Mark the remaining gaps as `not found in source`.
