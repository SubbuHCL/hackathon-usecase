---
name: docgen-writer
description: Turns docgen facts files into the final documentation set (README, ARCHITECTURE, API, DATA_MODEL, EVENTS, CONFIGURATION, DEPENDENCIES, RUNBOOK, DEPLOYMENT) using the bundled templates, AUTO-GENERATED markers, draft-validate-merge flow, and quality gate. Use during docgen Step 6 and 7, or when regenerating a single doc file.
---

# DocGen Writer

Input: `{TARGET}/docs/.docgen/facts/*.md`. Output: `{TARGET}/docs/*.md`.
Write **only from facts**. If a fact is missing, go back to the analyser
phase. Do not fill gaps from memory.

## File map

| File | Generate when | Facts used | Template |
|---|---|---|---|
| `README.md` | always | 01, 02, 04, 07 | `templates/README.md` |
| `API.md` | phase 2 found endpoints, gRPC or GraphQL | 02 | `templates/API.md` |
| `DATA_MODEL.md` | phase 3 found entities, schemas or migrations | 03 | `templates/DATA_MODEL.md` |
| `EVENTS.md` | phase 4 found producers or consumers | 04 | `templates/EVENTS.md` |
| `CONFIGURATION.md` | always | 05 (+ 08 delivery column) | `templates/CONFIGURATION.md` |
| `DEPENDENCIES.md` | always | 01, 06 | `templates/DEPENDENCIES.md` |
| `RUNBOOK.md` | phase 7 found a Dockerfile, compose, a wrapper or package scripts | 07, 05, 08 | `templates/RUNBOOK.md` |
| `DEPLOYMENT.md` | phase 8 ran | 08 | `templates/DEPLOYMENT.md` |
| `ARCHITECTURE.md` | always, and **last** | all | `templates/ARCHITECTURE.md` |

Order: README, API, DATA_MODEL, EVENTS, CONFIGURATION, DEPENDENCIES, RUNBOOK,
DEPLOYMENT, then ARCHITECTURE.

## Template conventions (you must remove all scaffolding)

| Scaffolding | Meaning | What to do |
|---|---|---|
| `{{NAME}}` | value placeholder | Replace with the real value from facts. If unknown, write `not found in source`. |
| `<!-- GUIDE: ... -->` | instruction to you | Follow it, then delete the comment. |
| `<!-- IF: condition -->` ... `<!-- ENDIF -->` | optional section | If the condition holds, keep the content and delete both marker lines. Otherwise delete the whole section. |
| `<!-- HUMAN: ... -->` | human-owned zone marker | Keep it exactly. |
| `<!-- AUTO-GENERATED-START: x -->` / `END: x` | generated zone | Keep them exactly. Content between them is regenerated on every run. |

Repeating blocks (endpoints, entities, topics, env var groups): copy the
block once per item in the facts.

## Procedure per file

1. `view_file` the template and the facts files it uses.
2. Write the complete filled document to
   `{TARGET}/docs/.docgen/draft/<FILE>.md` with `write_to_file`.
3. Validate the draft:
   ```bash
   bash {SKILLS}/docgen-writer/scripts/validate-docs.sh {TARGET}/docs/.docgen/draft/<FILE>.md
   bash {SKILLS}/mermaid-diagrams/scripts/lint-mermaid.sh {TARGET}/docs/.docgen/draft/<FILE>.md
   ```
   Also validate every Mermaid block with the Mermaid MCP when it is connected
   (see the mermaid-diagrams skill). Fix the errors and re-run. Maximum 3 rounds.
4. Merge it into place:
   ```bash
   bash {SKILLS}/docgen-writer/scripts/merge-doc.sh {TARGET}/docs/.docgen/draft/<FILE>.md {TARGET}/docs/<FILE>.md
   ```
   - New file: created.
   - Existing docgen file: the human header is kept and the generated part is replaced.
   - Existing human file without markers: left alone, and the draft is saved
     as `<FILE>.docgen.md`. Mention this in the report.
5. Note the file as done in `state.md`.

Links between docs: link only to files that were actually generated. The
validator fails on broken `./X.md` links. Skipped files must be removed from
the README documentation table.

## Writing rules

1. **Evidence**: every section that states code facts starts with, or
   contains, `_Source: \`path:line\`_` or `_Derived from ..._`.
2. **No invention**: every endpoint, field, topic, variable and resource must
   exist in the facts. Unknown values say `not found in source`.
3. **Interpretation is labelled**: business purpose and intent start with
   "Inferred from ...".
4. **Secrets**: never print real secret values, even when the facts contain
   them. Write `(secret)`.
5. **Style**: tables over prose, short sentences, no marketing language,
   present tense, and real names (class, table, topic) in backticks.
6. **Diagrams**: add a Mermaid diagram wherever it clarifies a flow,
   relationship or lifecycle (per the template IF conditions). Every diagram
   is validated.
7. **Dates**: `Last updated:` uses today's date in `YYYY-MM-DD` format.

## Final gate (Step 7)

```bash
bash {SKILLS}/docgen-writer/scripts/validate-docs.sh {TARGET}/docs
bash {SKILLS}/mermaid-diagrams/scripts/lint-mermaid.sh {TARGET}/docs
```

Both must exit 0. Warnings (`TODO(docgen)`, missing dates) go in the report.
