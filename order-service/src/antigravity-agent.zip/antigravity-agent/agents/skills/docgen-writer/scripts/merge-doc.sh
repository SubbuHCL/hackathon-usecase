#!/usr/bin/env bash
# Merge a validated draft into its final doc without touching human content.
# Usage: merge-doc.sh <draft.md> <final.md>
#   final missing                -> draft is copied as the final file
#   final has docgen markers     -> keep final's human header (everything above
#                                   the first AUTO-GENERATED-START), replace the
#                                   rest with the draft's generated part
#   final has NO docgen markers  -> human-owned file; NOT overwritten. The draft
#                                   is written next to it as <name>.docgen.md
set -u

DRAFT="${1:-}"; FINAL="${2:-}"
[ -f "$DRAFT" ] && [ -n "$FINAL" ] || { echo "usage: merge-doc.sh <draft.md> <final.md>" >&2; exit 64; }

START_RE='<!-- AUTO-GENERATED-START:'
grep -q "$START_RE" "$DRAFT" || { echo "ERROR: draft has no AUTO-GENERATED-START marker: $DRAFT" >&2; exit 1; }

mkdir -p "$(dirname "$FINAL")"

if [ ! -f "$FINAL" ]; then
  cp "$DRAFT" "$FINAL"
  echo "created: $FINAL"
  exit 0
fi

if ! grep -q "$START_RE" "$FINAL"; then
  ALT="${FINAL%.md}.docgen.md"
  cp "$DRAFT" "$ALT"
  echo "kept human file: $FINAL (no docgen markers). Wrote generated version to: $ALT"
  exit 0
fi

TMP="$FINAL.docgen-tmp.$$"
{
  awk -v re="$START_RE" 'index($0, re) { exit } { print }' "$FINAL"
  awk -v re="$START_RE" 'index($0, re) { on = 1 } on { print }' "$DRAFT"
} > "$TMP"

if cmp -s "$TMP" "$FINAL"; then
  rm -f "$TMP"
  echo "unchanged: $FINAL"
else
  mv "$TMP" "$FINAL"
  echo "updated: $FINAL (human header preserved)"
fi
