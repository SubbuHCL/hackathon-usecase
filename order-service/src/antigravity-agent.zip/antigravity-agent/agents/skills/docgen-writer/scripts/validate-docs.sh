#!/usr/bin/env bash
# Quality gate for generated docs.
# Usage: validate-docs.sh <docs-dir | file.md> [...]
# Checks per file:
#   E  AUTO-GENERATED-START/END markers balanced, matched by name, ordered
#   E  leftover template scaffolding: {{...}}, <!-- GUIDE:, <!-- IF:, <!-- ENDIF
#   E  leftover single-brace placeholders outside code blocks: {service-name}, {ISO-date}
#   E  unbalanced ``` fences
#   E  relative links to .md files that do not exist
#   W  generated block without a "Last updated: YYYY-MM-DD" line
#   W  TODO(docgen) markers (listed for the report)
# Exit 0 = no errors, 1 = errors. Skips docs/.docgen/ unless given explicitly.
set -u
[ $# -ge 1 ] || { echo "usage: validate-docs.sh <docs-dir|file.md> [...]" >&2; exit 64; }

FILES=""
for p in "$@"; do
  if [ -d "$p" ]; then
    FILES="$FILES$(find "$p" -name "*.md" -not -path "*/.docgen/*" -not -name "*.docgen-tmp.*" -type f | sort)
"
  elif [ -f "$p" ]; then FILES="$FILES$p
"; fi
done

TOTAL_E=0; TOTAL_W=0; N=0
while IFS= read -r f; do
  [ -n "$f" ] || continue
  N=$((N + 1))
  dir="$(cd "$(dirname "$f")" && pwd)"
  out="$(awk -v file="$f" '
    function E(m) { printf "%s:%d: ERROR %s\n", file, NR, m; e++ }
    function W(m) { printf "%s:%d: WARN  %s\n", file, NR, m; w++ }
    BEGIN { e = 0; w = 0; fence = 0; depth = 0 }
    /^[ \t]*```/ { fence = !fence }
    {
      line = $0
      if (match(line, /<!-- AUTO-GENERATED-START: *[A-Za-z0-9_-]+/)) {
        name = substr(line, RSTART, RLENGTH); sub(/.*START: */, "", name)
        depth++; stack[depth] = name; open[name]++; startline[depth] = NR; dated[depth] = 0
      }
      if (line ~ /Last updated: *[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]/ && depth > 0) dated[depth] = 1
      if (match(line, /<!-- AUTO-GENERATED-END: *[A-Za-z0-9_-]+/)) {
        name = substr(line, RSTART, RLENGTH); sub(/.*END: */, "", name)
        if (depth == 0) E("END marker \"" name "\" without a START")
        else {
          if (stack[depth] != name) E("END \"" name "\" closes START \"" stack[depth] "\" (line " startline[depth] ")")
          if (!dated[depth] && depth == 1) W("block \"" stack[depth] "\" has no \"Last updated: YYYY-MM-DD\" line")
          depth--
        }
      }
      if (line ~ /\{\{[^}]*\}\}/) E("unfilled template placeholder: " substr(line, match(line, /\{\{[^}]*\}\}/), RLENGTH))
      if (line ~ /<!-- *GUIDE:/) E("template GUIDE comment left in output")
      if (line ~ /<!-- *(IF:|ENDIF)/) E("template IF/ENDIF marker left in output")
      t = line; gsub(/`[^`]*`/, "", t)
      if (!fence && match(t, /(^|[^$])\{[a-z][a-z0-9]*(-[a-z0-9]+)+\}|\{ISO-date\}|\{e\.g\./)) E("placeholder-like text outside code: " substr(t, RSTART, RLENGTH))
      if (line ~ /TODO\(docgen\)/) W("open TODO: " line)
      s = line
      while (match(s, /\]\(\.?\/?[A-Za-z0-9_.\/-]+\.md(#[^)]*)?\)/)) {
        link = substr(s, RSTART + 2, RLENGTH - 3); s = substr(s, RSTART + RLENGTH)
        sub(/#.*/, "", link); print "LINK\t" NR "\t" link
      }
    }
    END {
      if (fence) { printf "%s: ERROR unbalanced ``` code fences\n", file; e++ }
      while (depth > 0) { printf "%s:%d: ERROR START \"%s\" never closed\n", file, startline[depth], stack[depth]; e++; depth-- }
      n = 0; for (k in open) n++
      if (n == 0) { printf "%s: WARN  no AUTO-GENERATED block (human-only file?)\n", file; w++ }
      printf "COUNTS\t%d\t%d\n", e, w
    }' "$f")"
  printf '%s\n' "$out" | grep -vE '^(LINK|COUNTS)' | grep . || true
  le=0
  while IFS="$(printf '\t')" read -r tag ln link; do
    [ "$tag" = "LINK" ] || continue
    if [ ! -f "$dir/$link" ]; then echo "$f:$ln: ERROR broken link to $link"; le=$((le + 1)); fi
  done <<EOF
$out
EOF
  c="$(printf '%s\n' "$out" | grep '^COUNTS' | tail -1)"
  e=$(printf '%s' "$c" | cut -f2); w=$(printf '%s' "$c" | cut -f3)
  TOTAL_E=$((TOTAL_E + ${e:-0} + le)); TOTAL_W=$((TOTAL_W + ${w:-0}))
done <<EOF
$FILES
EOF

echo "validate-docs: $N file(s), $TOTAL_E error(s), $TOTAL_W warning(s)"
[ "$TOTAL_E" -eq 0 ]
