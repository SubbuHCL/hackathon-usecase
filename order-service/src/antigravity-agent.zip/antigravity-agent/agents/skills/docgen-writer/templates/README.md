# {{SERVICE_NAME}}

{{ONE_PARAGRAPH_PURPOSE}}

<!-- HUMAN: Add context, team notes, or links to related systems above this line. -->

---

<!-- AUTO-GENERATED-START: readme -->
<!-- Last updated: {{ISO_DATE}} | generator: docgen (Antigravity) | sources: facts/01-stack.md, facts/02-api.md, facts/04-events.md -->

## What This Service Does

<!-- GUIDE: 1-2 short paragraphs. What it owns, what it serves, who consumes it. Derive this from the domain entities, endpoints and events. Prefix interpretation with "Inferred from ...". -->
{{SERVICE_ROLE}}

## Tech Stack

| Layer | Technology |
|---|---|
| Language | {{LANGUAGE_AND_VERSION}} |
| Framework | {{FRAMEWORK_AND_VERSION}} |
| Persistence | {{PERSISTENCE_OR_NONE}} |
| Messaging | {{MESSAGING_OR_NONE}} |
| Transport | {{TRANSPORT_AND_PORT}} |
| Build | {{BUILD_TOOL_AND_WRAPPER}} |

<!-- GUIDE: Delete any row whose value is "none" if that is clearer. -->

## Quick Start

```bash
{{FASTEST_LOCAL_RUN_COMMANDS}}
```

See [RUNBOOK.md](./RUNBOOK.md) for the full local development guide.

## Key Capabilities

<!-- GUIDE: 3-6 bullets, each traceable to an endpoint, event or job in the facts. -->
- {{CAPABILITY}}

## Documentation

<!-- GUIDE: List only files that were generated. Remove rows for skipped files. -->
| File | Contents |
|---|---|
| [ARCHITECTURE.md](./ARCHITECTURE.md) | System design, C4 diagrams, data flows, boundaries |
| [API.md](./API.md) | {{API_SUMMARY}} |
| [EVENTS.md](./EVENTS.md) | {{EVENTS_SUMMARY}} |
| [DATA_MODEL.md](./DATA_MODEL.md) | {{DATA_SUMMARY}} |
| [CONFIGURATION.md](./CONFIGURATION.md) | Environment variables and configuration |
| [DEPENDENCIES.md](./DEPENDENCIES.md) | Runtime and build dependencies |
| [RUNBOOK.md](./RUNBOOK.md) | Local development, Docker, operations |
| [DEPLOYMENT.md](./DEPLOYMENT.md) | {{DEPLOYMENT_SUMMARY}} |

<!-- AUTO-GENERATED-END: readme -->
