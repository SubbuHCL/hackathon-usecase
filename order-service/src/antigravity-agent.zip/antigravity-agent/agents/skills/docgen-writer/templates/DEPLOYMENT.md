# Deployment

{{DEPLOYMENT_INTRO: what ships the service, target platform, and notable constraints}}

<!-- HUMAN: Add production cluster names, change windows, approval gates, the owning team, and on-call rotations above this line. -->

---

<!-- AUTO-GENERATED-START: deployment -->
<!-- Last updated: {{ISO_DATE}} | generator: docgen (Antigravity) | sources: facts/08-deployment.md -->

## Artifact Sources

| Layer | Status | Source |
|---|---|---|
| Cloud resources (IaC) | {{found/user-described/not provided}} | `{{FILES_OR_DASH}}` |
| Workload (Helm / k8s) | {{found/user-described/not provided}} | `{{FILES_OR_DASH}}` |
| Delivery (CI/CD) | {{found/user-described/not provided}} | `{{FILES_OR_DASH}}` |

<!-- IF: Helm chart present -->
## Chart Overview

| Field | Value |
|---|---|
| Chart | `{{CHART_NAME}}` `{{CHART_VERSION}}` |
| App version (image tag) | `{{APP_VERSION}}` |
| Archetype | {{api/frontend/worker/cronjob/stateful}} |
| Image | `{{IMAGE_REPOSITORY}}` |
| Subcharts | {{DEPENDENCIES_OR_NONE}} |
| Location | `{{CHART_PATH}}` |
<!-- ENDIF -->

## Cloud Architecture

<!-- GUIDE: The icon diagram. Build it from the facts diagram plan. Every node traces to IaC, Helm, a pipeline, or a user description. Use brand icons only if they were resolved (mermaid-diagrams skill), otherwise the built-ins cloud/server/database/disk/internet. Labels must not contain / . { } or the middle dot. There are no edge labels. -->

```mermaid
architecture-beta
    group cloud({{PROVIDER_ICON}})[{{PROVIDER}} {{REGION}}]
    group cluster({{CLUSTER_ICON}})[{{CLUSTER_NAME}}] in cloud
    group ns(server)[{{NAMESPACE}}] in cluster

    service users(internet)[Clients]
    service lb({{LB_ICON}})[{{INGRESS_OR_LB}}] in cloud
    service app({{WORKLOAD_ICON}})[{{SERVICE_NAME}}] in ns
    service db({{DB_ICON}})[{{DATABASE}}] in cloud
    service secrets({{SECRETS_ICON}})[{{SECRET_STORE}}] in cloud

    users:R --> L:lb
    lb:R --> L:app
    app:R --> L:db
    secrets:B --> T:app
```

<!-- GUIDE: The fallback diagram. Keep it: it renders on GitHub and carries the protocols and ports that architecture-beta cannot label. -->

```mermaid
graph TB
  users["Clients"] -->|"HTTPS 443"| ing["Ingress<br/>{{HOST}}"]
  ing -->|"HTTP {{SERVICE_PORT}}"| svc["Service {{SERVICE_NAME}}<br/>{{SERVICE_TYPE}}"]
  svc --> pod["{{WORKLOAD_KIND}} {{WORKLOAD_NAME}}<br/>replicas {{REPLICAS}}"]
  cm[("ConfigMap {{CONFIGMAP}}")] -.->|envFrom| pod
  sec[("Secret {{SECRET}}")] -.->|envFrom| pod
  pod -->|"{{DB_PROTOCOL}}"| db[("{{DATABASE}}")]
```

> Layers not shown: {{NOT_PROVIDED_LAYERS_OR_NONE}}

<!-- IF: CI/CD pipeline found -->
## Delivery Pipeline

```mermaid
graph LR
  repo["{{SOURCE_REPO}}"] -->|"{{TRIGGER}}"| ci["{{CI_SYSTEM}}<br/>{{PIPELINE_FILE}}"]
  ci --> build["build and test"]
  build --> img["push image<br/>{{REGISTRY}}"]
  img --> deploy["{{DEPLOY_MECHANISM}}"]
  deploy --> env["{{TARGET_ENVIRONMENT}}"]
```

| Stage | What happens | Source |
|---|---|---|
| {{STAGE}} | {{ACTION}} | `{{FILE_LINE}}` |
<!-- ENDIF -->

<!-- IF: 2 or more values files differ -->
## Environments

<!-- GUIDE: Only rows that differ between environments. -->
| Setting | {{ENV_1}} | {{ENV_2}} |
|---|---|---|
| {{SETTING}} | `{{VALUE_1}}` | `{{VALUE_2}}` |
<!-- ENDIF -->

## Configuration Injection

| Env var | Delivery | Key / remote ref |
|---|---|---|
| `{{VAR}}` | {{literal/ConfigMap:name/Secret:name/ExternalSecret:store}} | `{{KEY}}` |

See [CONFIGURATION.md](./CONFIGURATION.md) for defaults and descriptions.

## Scaling and Resilience

<!-- GUIDE: Only rows whose template or values exist. -->
| Aspect | Value | Source |
|---|---|---|
| Replicas | `{{REPLICAS}}` | `{{FILE}}` |
| HPA | `min {{MIN}}, max {{MAX}}, {{METRIC}}` | `{{FILE}}` |
| PDB | `{{PDB}}` | `{{FILE}}` |
| CPU request / limit | `{{CPU}}` | `{{FILE}}` |
| Memory request / limit | `{{MEM}}` | `{{FILE}}` |
| Liveness probe | `{{PROBE}}` | `{{FILE}}` |
| Readiness probe | `{{PROBE}}` | `{{FILE}}` |

<!-- IF: ingress template present -->
## Ingress and TLS

| Field | Value |
|---|---|
| Class | `{{INGRESS_CLASS}}` |
| Hosts | `{{HOSTS}}` |
| Paths | `{{PATHS}}` |
| TLS | {{CERT_MANAGER_ISSUER/STATIC_SECRET/DISABLED}} |
<!-- ENDIF -->

## Secrets and Identity

| Field | Value |
|---|---|
| Secret strategy | {{k8s-native/external-secrets/none}} |
| Secret backend | {{VAULT/AWS_SM/GCP_SM/AZURE_KV/NONE}} |
| ServiceAccount | `{{SERVICE_ACCOUNT}}` |
| Workload identity | {{NONE/IRSA_ROLE/GCP_SA/AZURE_CLIENT_ID}} |

<!-- IF: Helm chart present -->
## Install, Upgrade, Rollback

```bash
helm upgrade --install {{RELEASE}} {{CHART_PATH}} -f {{CHART_PATH}}/{{VALUES_FILE}} -n {{NAMESPACE}}
helm diff upgrade {{RELEASE}} {{CHART_PATH}} -f {{CHART_PATH}}/{{VALUES_FILE}} -n {{NAMESPACE}}   # helm-diff plugin
helm rollback {{RELEASE}} -n {{NAMESPACE}}
helm status {{RELEASE}} -n {{NAMESPACE}}
```
<!-- ENDIF -->

<!-- AUTO-GENERATED-END: deployment -->
