# Runbook

<!-- HUMAN: Add production procedures, on-call steps, escalation contacts, or environment-specific notes above this line. -->

---

<!-- AUTO-GENERATED-START: runbook -->
<!-- Last updated: {{ISO_DATE}} | generator: docgen (Antigravity) | sources: facts/07-runtime.md, facts/05-config.md, facts/08-deployment.md -->

## Prerequisites

<!-- GUIDE: List only what the repo actually needs: the JDK/Node/Go/Python version (from the build file, .nvmrc, .java-version, .tool-versions), Docker if compose is present, and any CLI tools. -->
- {{PREREQUISITE}}

## Local Development

### 1. Start dependencies

<!-- IF: docker-compose present -->
```bash
docker compose up -d
```

| Service | Image | Port | Purpose |
|---|---|---|---|
| `{{NAME}}` | `{{IMAGE}}` | `{{PORT}}` | {{PURPOSE}} |
<!-- ENDIF -->

### 2. Configure

<!-- GUIDE: Name the required variables without defaults (from facts/05-config.md) and how to set them locally: a .env copy, application-local.yml, or exports. -->
```bash
{{CONFIG_COMMANDS}}
```

See [CONFIGURATION.md](./CONFIGURATION.md) for every variable.

### 3. Run

<!-- GUIDE: Use the project's build wrapper (mvnw/gradlew) or package scripts exactly as found. -->
```bash
{{RUN_COMMAND}}
```

### 4. Verify

<!-- GUIDE: Use the real health endpoint, e.g. /actuator/health when actuator is present. -->
```bash
curl -s http://localhost:{{PORT}}{{HEALTH_PATH}}
```

## Build and Test

```bash
{{TEST_COMMAND}}
{{PACKAGE_COMMAND}}
```

Artifact: `{{ARTIFACT_PATH}}`

<!-- IF: Dockerfile present -->
## Docker

```bash
docker build -t {{IMAGE_NAME}}:local .
docker run --rm -p {{PORT}}:{{PORT}} {{REQUIRED_ENV_FLAGS}} {{IMAGE_NAME}}:local
```

| | |
|---|---|
| Base image | `{{BASE_IMAGE}}` |
| Exposed port | `{{PORT}}` |
| Entrypoint | `{{ENTRYPOINT}}` |
<!-- ENDIF -->

<!-- IF: Helm chart present -->
<!-- AUTO-GENERATED-START: runbook-k8s -->
## Kubernetes (Helm)

Chart: `{{CHART_PATH}}` · Release: `{{RELEASE}}` · Namespace: `{{NAMESPACE}}`. See [DEPLOYMENT.md](./DEPLOYMENT.md).

```bash
helm upgrade --install {{RELEASE}} {{CHART_PATH}} -f {{CHART_PATH}}/{{VALUES_FILE}} -n {{NAMESPACE}}
helm history {{RELEASE}} -n {{NAMESPACE}}
helm rollback {{RELEASE}} -n {{NAMESPACE}}
```

```bash
kubectl get pods -n {{NAMESPACE}} -l app.kubernetes.io/instance={{RELEASE}}
kubectl logs -n {{NAMESPACE}} -l app.kubernetes.io/instance={{RELEASE}} --tail=200 -f
kubectl describe pod -n {{NAMESPACE}} -l app.kubernetes.io/instance={{RELEASE}}
kubectl rollout restart {{WORKLOAD_KIND}}/{{WORKLOAD_NAME}} -n {{NAMESPACE}}
kubectl port-forward -n {{NAMESPACE}} svc/{{SERVICE_NAME}} {{LOCAL_PORT}}:{{SERVICE_PORT}}
```
<!-- AUTO-GENERATED-END: runbook-k8s -->
<!-- ENDIF -->

## Troubleshooting

<!-- GUIDE: 2-5 rows derived from the code: required env vars without defaults, dependencies that must be up, and migrations that run on startup. Do not invent incidents. -->
| Symptom | Likely cause | Check |
|---|---|---|
| {{SYMPTOM}} | {{CAUSE}} | {{CHECK}} |

<!-- IF: migrations, scheduled jobs, or admin endpoints exist -->
## Useful Commands

```bash
{{SERVICE_SPECIFIC_COMMANDS}}
```
<!-- ENDIF -->

<!-- AUTO-GENERATED-END: runbook -->
