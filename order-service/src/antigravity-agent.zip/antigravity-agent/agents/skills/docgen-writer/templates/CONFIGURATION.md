# Configuration

{{CONFIG_INTRO: how configuration is externalised and overridden}}

_Derived from: {{CONFIG_FILES_AND_CLASSES}}._

<!-- HUMAN: Add the secret-management approach, per-environment overrides, or Vault/SSM paths above this line. -->

---

<!-- AUTO-GENERATED-START: configuration -->
<!-- Last updated: {{ISO_DATE}} | generator: docgen (Antigravity) | sources: facts/05-config.md, facts/08-deployment.md -->

## Environment Variables

<!-- GUIDE: Group the rows under H3 headings by concern: Server, Database, Messaging, Security, Downstream Services, Application. Drop empty groups. Never print a real secret value; write "(secret)". Keep the Delivery column only when facts/08-deployment.md exists, otherwise delete that column. The delivery source is one of: literal, ConfigMap:<name>, Secret:<name>, ExternalSecret:<store>. Link the non-literal values to DEPLOYMENT.md#configuration-injection. -->

### {{GROUP}}

| Variable | Default | Required | Property | Delivery | Description |
|---|---|---|---|---|---|
| `{{VAR}}` | `{{DEFAULT_OR_DASH}}` | {{Yes/No}} | `{{PROPERTY_KEY}}` | {{DELIVERY_SOURCE}} | {{DESCRIPTION}} |

<!-- IF: @ConfigurationProperties / settings classes exist -->
## Configuration Classes

### `{{CLASS}}` (prefix `{{PREFIX}}`)

| Property | Env override | Type | Default | Description |
|---|---|---|---|---|
| `{{PREFIX}}.{{FIELD}}` | `{{ENV_NAME}}` | `{{TYPE}}` | `{{DEFAULT}}` | {{DESCRIPTION}} |
<!-- ENDIF -->

<!-- IF: profile-specific config files exist -->
## Profiles

| Profile | File | Overrides |
|---|---|---|
| `{{PROFILE}}` | `{{FILE}}` | {{KEYS_OVERRIDDEN}} |
<!-- ENDIF -->

<!-- IF: the .env.example cross-check found differences -->
## .env.example Drift

| Variable | Status |
|---|---|
| `{{VAR}}` | {{in .env.example only (possibly dead) / used in code but undocumented}} |
<!-- ENDIF -->

<!-- AUTO-GENERATED-END: configuration -->
