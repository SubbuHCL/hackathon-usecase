# Data Model

{{DATA_INTRO_ONE_PARAGRAPH}}

_Derived from source code: {{ENTITY_AND_MIGRATION_FILES}}._

<!-- HUMAN: Add indexing strategy, partitioning, retention, or soft-delete conventions above this line. -->

---

<!-- AUTO-GENERATED-START: data_model -->
<!-- Last updated: {{ISO_DATE}} | generator: docgen (Antigravity) | sources: facts/03-data.md -->

## Database

| | |
|---|---|
| Type | {{DATABASE_TYPE}} |
| Access | {{ORM_OR_DRIVER}} |
| Schema management | {{FLYWAY/LIQUIBASE/PRISMA/ALEMBIC/DDL_AUTO}} |
| Migrations | {{MIGRATION_COUNT_AND_PATH}} |

<!-- IF: 2 or more entities and at least one relationship -->
## Entity Relationships

```mermaid
erDiagram
  {{TABLE_A}} {
    {{type}} {{column}} PK
  }
  {{TABLE_B}} {
    {{type}} {{column}} FK
  }
  {{TABLE_A}} ||--o{ {{TABLE_B}} : "{{relation}}"
```
<!-- ENDIF -->

---

## Entities

<!-- GUIDE: One H3 per entity in facts/03-data.md. -->

### `{{ENTITY_CLASS}}` → `{{TABLE_OR_COLLECTION}}`

{{BUSINESS_MEANING}}

_Source: `{{ENTITY_FILE_LINE}}`_

| Column | Type | Constraints | Description |
|---|---|---|---|
| `{{COLUMN}}` | `{{TYPE}}` | {{PK/NOT NULL/UNIQUE/FK/nullable}} | {{DESCRIPTION}} |

<!-- IF: the entity has relationships -->
**Relationships**

| Relation | Target | Via | Fetch |
|---|---|---|---|
| `{{ANNOTATION}}` | `{{TARGET}}` | `{{JOIN_COLUMN_OR_MAPPED_BY}}` | {{LAZY/EAGER}} |
<!-- ENDIF -->

<!-- IF: a status field has transitions visible in code -->
**Lifecycle**

```mermaid
stateDiagram-v2
  [*] --> {{INITIAL_STATE}}
  {{INITIAL_STATE}} --> {{NEXT_STATE}} : {{METHOD}}
  {{NEXT_STATE}} --> [*]
```
<!-- ENDIF -->

<!-- IF: the repository has custom queries -->
**Queries** (`{{REPOSITORY}}`)

| Method | Purpose |
|---|---|
| `{{METHOD_SIGNATURE}}` | {{PURPOSE}} |
<!-- ENDIF -->

<!-- AUTO-GENERATED-END: data_model -->
