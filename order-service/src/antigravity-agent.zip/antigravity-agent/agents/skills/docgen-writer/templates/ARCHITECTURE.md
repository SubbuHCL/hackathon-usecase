# Architecture

{{ARCHITECTURE_INTRO: what the service is, its core responsibility, and where it sits in the wider system}}

<!-- HUMAN: Add ADRs, design rationale, or historical context above this line. -->

---

<!-- AUTO-GENERATED-START: architecture -->
<!-- Last updated: {{ISO_DATE}} | generator: docgen (Antigravity) | sources: facts/01..08 -->

## Overview

{{SERVICE_NAME}} is responsible for {{OWNERSHIP_STATEMENT}}.

| | |
|---|---|
| Stack | {{LANGUAGE}} · {{FRAMEWORK}} · {{PERSISTENCE}} · {{MESSAGING}} |
| Runtime | {{TRANSPORT_AND_PORT}} |
| Knowledge graph | {{CODEGRAPH_NODES_EDGES_OR_NOT_USED}} |

## System Context

<!-- GUIDE: C4Context via the c4-architecture skill. People and external systems come from facts/02 (callers) and facts/06 (downstream). -->

```mermaid
C4Context
  title System Context - {{SERVICE_NAME}}
  Person(client, "{{CLIENT_TYPE}}", "{{WHAT_THEY_DO}}")
  System(svc, "{{SERVICE_NAME}}", "{{PURPOSE}}")
  System_Ext(ext, "{{EXTERNAL_SYSTEM}}", "{{WHY_IT_IS_CALLED}}")
  Rel(client, svc, "{{VERB}}", "{{PROTOCOL}}")
  Rel(svc, ext, "{{VERB}}", "{{PROTOCOL}}")
```

## Containers

<!-- GUIDE: C4Container. Use one ContainerQueue per topic, never a single "Kafka" box. -->

```mermaid
C4Container
  title Container Diagram - {{SERVICE_NAME}}
  Person(client, "{{CLIENT_TYPE}}", "{{WHAT_THEY_DO}}")
  System_Boundary(b, "{{SERVICE_NAME}}") {
    Container(app, "{{SERVICE_NAME}}", "{{LANGUAGE_FRAMEWORK}}", "{{PURPOSE}}")
    ContainerDb(db, "{{DATABASE}}", "{{DB_TECH}}", "{{WHAT_IT_STORES}}")
  }
  ContainerQueue(topic1, "{{TOPIC}}", "{{BROKER}}", "{{EVENT_MEANING}}")
  System_Ext(down, "{{DOWNSTREAM}}", "{{PURPOSE}}")
  Rel(client, app, "{{VERB}}", "{{PROTOCOL_PORT}}")
  Rel(app, db, "Reads and writes", "{{DB_PROTOCOL}}")
  Rel(app, topic1, "Publishes to")
  Rel(app, down, "{{VERB}}", "{{PROTOCOL}}")
```

<!-- IF: internal structure is non-trivial (3 or more layers, CQRS, a reactive pipeline) -->
## Components

```mermaid
C4Component
  title Components - {{SERVICE_NAME}}
  Container_Boundary(app, "{{SERVICE_NAME}}") {
    Component(api, "{{CONTROLLER_LAYER}}", "{{TECH}}", "{{RESPONSIBILITY}}")
    Component(svc, "{{SERVICE_LAYER}}", "{{TECH}}", "{{RESPONSIBILITY}}")
    Component(repo, "{{REPOSITORY_LAYER}}", "{{TECH}}", "{{RESPONSIBILITY}}")
  }
  Rel(api, svc, "Calls")
  Rel(svc, repo, "Uses")
```
<!-- ENDIF -->

## Internal Structure

| Layer | Package / directory | Responsibility |
|---|---|---|
| {{LAYER}} | `{{PACKAGE}}` | {{RESPONSIBILITY}} |

## Key Data Flows

<!-- GUIDE: One H3 per HIGH blast-radius endpoint or event-driven flow, as a sequenceDiagram (or C4Dynamic). At most 5 flows. -->

### {{FLOW_NAME}}

```mermaid
sequenceDiagram
  participant C as {{CALLER}}
  participant S as {{SERVICE_NAME}}
  participant D as {{DEPENDENCY}}
  C->>S: {{REQUEST}}
  S->>D: {{CALL}}
  D-->>S: {{RESULT}}
  S-->>C: {{RESPONSE}}
```

<!-- IF: facts/08-deployment.md exists -->
## Deployment View

<!-- GUIDE: C4Deployment, with nodes cluster, namespace, workload and data services. Full details are in DEPLOYMENT.md. -->

```mermaid
C4Deployment
  title Deployment - {{SERVICE_NAME}} ({{ENV}})
  Deployment_Node(cloud, "{{PROVIDER}} {{REGION}}", "{{PROVIDER}}") {
    Deployment_Node(k8s, "{{CLUSTER}}", "Kubernetes") {
      Deployment_Node(ns, "{{NAMESPACE}}", "Namespace") {
        Container(pod, "{{SERVICE_NAME}}", "{{LANGUAGE}}", "replicas {{REPLICAS}}")
      }
    }
    ContainerDb(db, "{{DATABASE}}", "{{DB_SERVICE}}", "{{PURPOSE}}")
  }
  Rel(pod, db, "Reads and writes", "{{DB_PROTOCOL}}")
```

See [DEPLOYMENT.md](./DEPLOYMENT.md) for the topology, configuration injection, scaling and delivery pipeline.
<!-- ENDIF -->

## Outbound Dependencies

| Service | Protocol | Used for | Resilience |
|---|---|---|---|
| {{SERVICE}} | {{PROTOCOL}} | {{PURPOSE}} | {{RETRY_CIRCUIT_BREAKER_OR_NONE}} |

## Boundaries

- **Owns**: {{DATA_AND_OPERATIONS_IT_IS_AUTHORITATIVE_FOR}}
- **Does not own**: {{WHAT_IT_READS_OR_DELEGATES}}
- **Consumed by**: {{CALLERS_AND_EVENT_CONSUMERS_OR_UNKNOWN}}

<!-- AUTO-GENERATED-END: architecture -->
