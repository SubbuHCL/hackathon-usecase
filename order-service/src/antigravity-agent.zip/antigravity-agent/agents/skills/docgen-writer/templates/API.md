# API Reference

{{API_INTRO_ONE_PARAGRAPH}}

_Derived from source code: {{CONTROLLER_FILES}}._ {{SPEC_CROSSCHECK_NOTE}}

<!-- HUMAN: Add usage examples, Postman collections, or integration notes above this line. -->

---

<!-- AUTO-GENERATED-START: api -->
<!-- Last updated: {{ISO_DATE}} | generator: docgen (Antigravity) | sources: facts/02-api.md -->

## Overview

| | |
|---|---|
| Base path | `{{BASE_PATH}}` |
| Auth | {{AUTH_MODEL}} |
| Content type | `{{CONTENT_TYPE}}` |
| Error format | {{ERROR_FORMAT_OR_NOT_FOUND}} |

## Endpoint Summary

| Method | Path | Purpose | Blast radius |
|---|---|---|---|
| `{{METHOD}}` | `{{PATH}}` | {{PURPOSE}} | {{SEVERITY}} |

---

## Endpoints

<!-- GUIDE: One H3 per resource group (usually per controller). Inside it, one H4 block per endpoint. Repeat the block for every endpoint in facts/02-api.md. -->

### {{RESOURCE_GROUP}}

#### `{{METHOD}}` `{{PATH}}`

{{WHAT_THE_OPERATION_DOES}}

_Source: `{{HANDLER_FILE_LINE}}`_

**Request**

| Parameter | In | Type | Required | Description |
|---|---|---|---|---|
| `{{NAME}}` | {{path/query/header/body}} | `{{TYPE}}` | {{Yes/No}} | {{DESCRIPTION}} |

<!-- IF: the endpoint has a request body -->
```json
{{REQUEST_BODY_EXAMPLE_FROM_DTO_FIELDS}}
```
<!-- ENDIF -->

**Responses**

| Status | When | Body |
|---|---|---|
| `{{STATUS}}` | {{CONDITION}} | `{{TYPE}}` |

**Blast Radius**

| | |
|---|---|
| Severity | `{{HIGH/MEDIUM/LOW}}` |
| Rationale | {{ONE_SENTENCE}} |
| Mutates data | {{Yes/No}} |
| Downstream consumers | {{CONSUMERS_OR_NONE_IDENTIFIED}} |
| Side effects | {{EVENTS_CACHE_EXTERNAL_CALLS_OR_NONE}} |

<!-- IF: the handler call chain has 3 or more collaborators (service + repository + client/producer) -->
**Flow**

```mermaid
sequenceDiagram
  participant C as Client
  participant Ctl as {{CONTROLLER}}
  participant Svc as {{SERVICE}}
  participant Repo as {{REPOSITORY}}
  participant Ext as {{DOWNSTREAM_OR_BROKER}}
  C->>Ctl: {{METHOD}} {{PATH}}
  Ctl->>Svc: {{SERVICE_METHOD}}
  Svc->>Repo: {{QUERY_OR_SAVE}}
  Svc->>Ext: {{CALL_OR_PUBLISH}}
  Svc-->>Ctl: {{RESULT}}
  Ctl-->>C: {{STATUS}}
```
<!-- ENDIF -->

---

<!-- IF: gRPC services exist -->
## gRPC

**Proto**: `{{PROTO_PATH}}` · **Package**: `{{PACKAGE}}`

| Service | Method | Request | Response | Streaming |
|---|---|---|---|---|
| `{{SERVICE}}` | `{{METHOD}}` | `{{REQUEST}}` | `{{RESPONSE}}` | {{None/Server/Client/Bidi}} |
<!-- ENDIF -->

<!-- IF: the spec cross-check found discrepancies -->
## Spec Discrepancies

| Item | In code | In spec | Note |
|---|---|---|---|
| {{ITEM}} | {{Yes/No}} | {{Yes/No}} | {{NOTE}} |
<!-- ENDIF -->

<!-- AUTO-GENERATED-END: api -->
