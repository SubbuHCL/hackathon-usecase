# Events

{{EVENTS_INTRO: producer, consumer, or both, and the broader flow}}

_Derived from source code: {{LISTENER_AND_PRODUCER_FILES}}._

<!-- HUMAN: Add schema-registry links, consumer-group conventions, or redelivery policies above this line. -->

---

<!-- AUTO-GENERATED-START: events -->
<!-- Last updated: {{ISO_DATE}} | generator: docgen (Antigravity) | sources: facts/04-events.md -->

## Broker

| | |
|---|---|
| Type | {{KAFKA/RABBITMQ/SQS/SERVICE_BUS/PUBSUB/IN_PROCESS}} |
| Connection | see [CONFIGURATION.md](./CONFIGURATION.md) → `{{BOOTSTRAP_VARIABLE}}` |
| Client | {{SPRING_KAFKA/KAFKAJS/...}} |

## Topology

<!-- GUIDE: One diagram when there are 6 topics or fewer. Otherwise split it into "produced" and "consumed". Use the real upstream and downstream names when they are known, otherwise "unknown producer" or "unknown consumers". -->

```mermaid
graph LR
  up["{{UPSTREAM}}"] -->|produces| t1(["{{CONSUMED_TOPIC}}"])
  t1 -->|consumes| svc["{{SERVICE_NAME}}"]
  svc -->|produces| t2(["{{PRODUCED_TOPIC}}"])
  t2 -->|consumes| down["{{DOWNSTREAM}}"]
```

## Topics

| Topic | Direction | Payload | Consumer group |
|---|---|---|---|
| `{{TOPIC}}` | {{Produced/Consumed}} | `{{PAYLOAD_TYPE}}` | `{{GROUP_OR_DASH}}` |

---

<!-- GUIDE: One H3 per topic. -->

### `{{TOPIC}}` ({{Produced/Consumed}})

{{BUSINESS_MEANING_TRIGGER_AND_SIDE_EFFECTS}}

_Source: `{{FILE_LINE}}`_

**Payload** (`{{PAYLOAD_CLASS}}`)

| Field | Type | Description |
|---|---|---|
| `{{FIELD}}` | `{{TYPE}}` | {{DESCRIPTION}} |

<!-- IF: payload class not found -->
> Payload shape not found in source. The producer sends `{{EXPRESSION}}` at `{{FILE_LINE}}`.
<!-- ENDIF -->

<!-- IF: in-process application events exist (Spring ApplicationEvent, EventEmitter) -->
## In-Process Events

| Event | Published by | Handled by |
|---|---|---|
| `{{EVENT_CLASS}}` | `{{PUBLISHER_FILE_LINE}}` | `{{LISTENER_FILE_LINE}}` |
<!-- ENDIF -->

<!-- AUTO-GENERATED-END: events -->
