# Dependencies

<!-- HUMAN: Add the version-pinning strategy, known issues, or upgrade blockers above this line. -->

---

<!-- AUTO-GENERATED-START: dependencies -->
<!-- Last updated: {{ISO_DATE}} | generator: docgen (Antigravity) | sources: facts/01-stack.md, facts/06-outbound.md | build file: {{BUILD_FILE}} -->

## Notable Libraries

<!-- GUIDE: One row per role that has a match. Delete rows with no match. "managed" means the version comes from a BOM or parent POM. -->

| Role | Library | Version |
|---|---|---|
| HTTP framework | `{{LIB}}` | {{VERSION_OR_MANAGED}} |
| Data access | `{{LIB}}` | {{VERSION_OR_MANAGED}} |
| Migrations | `{{LIB}}` | {{VERSION_OR_MANAGED}} |
| Messaging | `{{LIB}}` | {{VERSION_OR_MANAGED}} |
| HTTP clients | `{{LIB}}` | {{VERSION_OR_MANAGED}} |
| Security | `{{LIB}}` | {{VERSION_OR_MANAGED}} |
| Observability | `{{LIB}}` | {{VERSION_OR_MANAGED}} |
| Testing | `{{LIB}}` | {{VERSION_OR_MANAGED}} |

<!-- IF: versions are BOM-managed -->
> Versions marked "managed" are controlled by `{{BOM_OR_PARENT}}` `{{BOM_VERSION}}`.
<!-- ENDIF -->

## Service Dependencies

<!-- GUIDE: Runtime dependencies on other services and infrastructure, from facts/06-outbound.md and 03/04. -->

| Dependency | Type | Protocol | Used for | Config |
|---|---|---|---|---|
| {{NAME}} | {{service/database/broker/cache/external API}} | {{REST/gRPC/JDBC/Kafka}} | {{PURPOSE}} | `{{URL_VARIABLE}}` |

## Runtime Libraries

| Library | Version |
|---|---|
| `{{GROUP:ARTIFACT_OR_PACKAGE}}` | {{VERSION}} |

## Build / Test Libraries

| Library | Version |
|---|---|
| `{{GROUP:ARTIFACT_OR_PACKAGE}}` | {{VERSION}} |

<!-- AUTO-GENERATED-END: dependencies -->
