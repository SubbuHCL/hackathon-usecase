# DocGen for Google Antigravity

A self-contained documentation agent for **Google Antigravity** (CLI, IDE and
app), tuned for **Gemini Flash**. It builds a **CodeGraph knowledge graph** of
the codebase, extracts evidence-backed facts from source code, and writes a
validated documentation set with C4 and Mermaid diagrams.

It was redesigned from the GitHub Copilot `docgen` agent
(`.github/agents/docgen.agent.md`) and has no runtime dependency on it.
Everything it needs is in this folder.

## What's in the box

```
antigravity-agent/
├── README.md                      ← this file
├── install.sh                     ← installs into a repo (.agents/) or globally (~/.gemini/config/)
└── .agents/                       ← Antigravity's native layout; copy as-is
    ├── agents/
    │   └── docgen.md              ← the agent (frontmatter + system prompt)
    ├── mcp_config.json            ← MCP servers: codegraph (local), mermaid (remote)
    └── skills/
        ├── codegraph-knowledge-graph/   build/sync/query the knowledge graph
        │   ├── SKILL.md
        │   ├── scripts/ensure-graph.sh, graph-query.sh
        │   └── references/query-recipes.md
        ├── docgen-analyser/             phases 1-7: stack, API, data, events, config, outbound, runtime
        │   ├── SKILL.md
        │   ├── scripts/preflight.sh, inventory.sh, find-code.sh,
        │   │           extract-endpoints.sh, extract-config.sh, lib.sh
        │   └── references/facts-format.md, phase-playbooks.md
        ├── docgen-deployment/           phases 8-9: Helm/k8s, IaC, CI/CD, cloud diagram plan
        │   ├── SKILL.md
        │   ├── scripts/discover-deploy.sh
        │   └── references/helm-k8s-extraction.md, icon-catalog.md
        ├── docgen-writer/               templates, draft → validate → merge, quality gate
        │   ├── SKILL.md
        │   ├── scripts/merge-doc.sh, validate-docs.sh
        │   └── templates/README, ARCHITECTURE, API, DATA_MODEL, EVENTS,
        │                 CONFIGURATION, DEPENDENCIES, RUNBOOK, DEPLOYMENT (.md)
        ├── c4-architecture/             C4 Mermaid diagrams
        │   ├── SKILL.md
        │   └── references/c4-syntax.md, common-mistakes.md, advanced-patterns.md
        └── mermaid-diagrams/            diagram rules + validation (MCP / mmdc / offline lint)
            ├── SKILL.md
            ├── scripts/lint-mermaid.sh
            └── references/syntax-safety.md
```

> `.agents/` is a hidden folder. In Finder press `Cmd+Shift+.` to see it.
> In a shell, use `ls -a`.

## Prerequisites

| Tool | Required | Why | Install |
|---|---|---|---|
| Google Antigravity (CLI, IDE or app) | yes | runs the agent | antigravity.google |
| bash, find, grep, awk, sed | yes | the skill scripts (macOS bash 3.2 and Linux both work) | preinstalled |
| **CodeGraph** | strongly recommended | builds the code knowledge graph | `npm i -g @colbymchenry/codegraph` |
| jq | optional | lets `install.sh` merge an existing `mcp_config.json` | `brew install jq` |
| Mermaid account | optional | the remote Mermaid MCP render check (free sign-in on first use) | mermaid.ai |
| mermaid-cli (`mmdc`) | optional | offline render check | `npm i -g @mermaid-js/mermaid-cli` |

Without CodeGraph the agent still works. It falls back to the grep-based
`find-code.sh` and says so in its report.

## Install

**Option A: copy the folder (simplest).** Use this when the target repo has
no `.agents/` folder yet:

```bash
cp -R antigravity-agent/.agents /path/to/your-repo/
chmod +x /path/to/your-repo/.agents/skills/*/scripts/*.sh
```

**Option B: installer (safe merge).** Use this when the repo already has
`.agents/`. Existing skills are kept, a changed same-named file is backed up
to `.agents/.docgen-backup-<ts>/`, and `mcp_config.json` is merged:

```bash
./antigravity-agent/install.sh /path/to/your-repo            # workspace install
./antigravity-agent/install.sh /path/to/your-repo --dry-run  # preview
./antigravity-agent/install.sh --global                      # all workspaces (~/.gemini/config/)
```

Then check the tools:

```bash
bash /path/to/your-repo/.agents/skills/docgen-analyser/scripts/preflight.sh /path/to/your-repo
```

Recommended `.gitignore` entries for the target repo: `.codegraph/` (the
local graph database) and `docs/.docgen/` (the working folder with facts,
drafts and run state).

## Run

1. Open the repository in Antigravity: run the CLI from the repo root, or open
   the folder in the IDE or app.
2. Select the agent with `/agents`, then **docgen**. In the CLI you can also
   launch it directly with `--agent docgen`.
3. Ask, for example:
   - `Document this repository.`
   - `Document services/order-service only.`
   - `Update API.md.` (incremental: re-runs only the API phase)
   - `Resume the docgen run.`

The agent asks **one** batch of questions (scope, stack confirmation,
deployment artifacts, exclusions). It may stop a second time if deployment
artifacts are missing. Answer `figure it out` to let it auto-detect
everything.

### Model: Gemini Flash

`docgen.md` sets `model: flash`. Antigravity's agent frontmatter accepts
only `inherit`, `flash` or `pro`; it cannot pin a point release. The exact
checkpoint behind `flash` is chosen in Antigravity's model settings.

- To run on **Gemini 3.7 Flash**, select it (or the Flash default) in
  Antigravity's model settings.
- Note: Google's model page lists `gemini-3.7-flash` as deprecated, with
  calls automatically routed to `gemini-3.8-flash`. The agent behaves the
  same on either. Nothing in the package depends on a specific Flash build.
- To try a stronger model for very large monorepos, change it to `model: pro`.

## How it works

```mermaid
graph LR
  s0["0 Setup<br/>preflight + state"] --> s1["1 Context<br/>one question batch"]
  s1 --> s2["2 Knowledge graph<br/>codegraph init or sync"]
  s2 --> s3["3 Inventory<br/>stack + phase plan"]
  s3 --> s4["4 Analysis<br/>facts 01-07"]
  s4 --> s5["5 Deployment<br/>facts 08"]
  s5 --> s6["6 Write<br/>draft, validate, merge"]
  s6 --> s7["7 Quality gate"]
  s7 --> s8["8 Report"]
```

These design choices are what make it reliable on a Flash-class model:

- **Knowledge graph first.** `ensure-graph.sh` runs `codegraph init` (or
  `sync` on later runs). The agent then answers "where / who calls / what
  depends" with `codegraph explore`, `routes`, `callers`, `callees` and
  `impact` instead of dozens of file reads. A small service is indexed in
  seconds.
- **Deterministic scripts do the mechanical extraction**: endpoints (with
  class-level prefixes and Feign clients separated), `${VAR:default}` config,
  `.env.example` drift, deployment discovery. The model spends its effort on
  understanding, not on composing long grep pipelines.
- **Facts files with `file:line` evidence** (`docs/.docgen/facts/`) separate
  analysis from writing, keep context small, and make hallucination visible.
- **Checkpointed state** (`docs/.docgen/state.md`) lets an interrupted run
  resume.
- **Explicit template scaffolding** (`{{X}}`, `<!-- GUIDE -->`,
  `<!-- IF -->`) plus a validator that fails on any leftover scaffolding,
  broken links, or unbalanced markers.
- **Diagram validation in three layers**: the Mermaid MCP render (when it is
  connected), the local `mmdc` render (when it is installed), and an offline
  lint that always runs.
- **Human content is never overwritten.** `merge-doc.sh` replaces only the
  `AUTO-GENERATED` region, and leaves human-only files untouched by writing
  `<FILE>.docgen.md` next to them.

## Output

`docs/` in the target directory: `README.md`, `ARCHITECTURE.md` (C4 context
and container views, plus deployment and data flows), `API.md`,
`DATA_MODEL.md`, `EVENTS.md`, `CONFIGURATION.md`, `DEPENDENCIES.md`,
`RUNBOOK.md` and `DEPLOYMENT.md`. Files whose phase found nothing are
skipped. The `AUTO-GENERATED-START/END` markers use the same names as the
Copilot docgen, so docs produced by either agent can be updated by the other.

## Differences from the Copilot docgen

| Area | Copilot docgen | Antigravity docgen |
|---|---|---|
| Runtime and format | `.github/agents/*.agent.md` (Copilot schema) | `.agents/agents/docgen.md` (Antigravity schema: `model`, `commandExecutionPolicy`, `skills`) |
| Model | Claude Sonnet | Gemini Flash (`model: flash`) |
| Knowledge graph | not used | CodeGraph built or synced every run; graph-first queries with grep fallback |
| Extraction | prose grep instructions | tested scripts (macOS and Linux) |
| Intermediate state | none | facts files with evidence, plus a resumable `state.md` |
| Mermaid | assumes `mermaid-mcp` icon and syntax tools | discovers MCP tools at runtime; `mmdc` and offline lint fallbacks |
| Templates | `{...}` prose placeholders | `{{X}}` / GUIDE / IF scaffolding that the validator enforces |
| Updating existing docs | instructions only | `merge-doc.sh` (human header preserved; human-only files never overwritten) |

## Smoke test after install

1. Run `preflight.sh` (above). It should print `PREFLIGHT: ok`.
2. Run `bash .agents/skills/codegraph-knowledge-graph/scripts/ensure-graph.sh .`
   It should end with `STATUS: ready`.
3. In Antigravity, run `/agents`. `docgen` should be listed, and the six
   skills should appear in the customisations view.
4. Ask docgen: `Document this repository, figure it out.`, then check
   `docs/` and `docs/.docgen/state.md`.

## Troubleshooting

| Symptom | Fix |
|---|---|
| The agent doesn't appear in `/agents` | Confirm the file is at `<repo>/.agents/agents/docgen.md` (or `~/.gemini/config/agents/`). Some CLI versions list workspace agents only via the in-session `/agents`, not `agy agents`. |
| The subagent hangs on start | Antigravity can hang on an unknown tool name in `tools:`. Remove tools your version doesn't have (the list is `view_file`, `grep_search`, `write_to_file`, `replace_file_content`, `run_command`), or delete the `tools:` block to inherit the defaults. |
| Shell commands blocked or prompting constantly | `commandExecutionPolicy: auto` is set. Use `sandbox` for stricter isolation, or approve the `bash .agents/skills/...` prefix once. |
| `codegraph` tools are missing in MCP | The CodeGraph MCP server only exposes tools if `.codegraph/` existed when the session started. The agent uses the CLI wrapper (`graph-query.sh`) anyway, so nothing breaks. Restart the session to get the MCP tools. |
| Mermaid MCP is not connected | It needs a free Mermaid sign-in (OAuth) on first use. Without it, validation falls back to `mmdc` or the lint. |
| Brand icons are blank on GitHub | GitHub doesn't load Iconify icon packs for `architecture-beta`. DEPLOYMENT.md always includes a `graph TB` fallback that renders everywhere. |
| Workspace `mcp_config.json` ignored | Some CLI versions only load `~/.gemini/config/mcp_config.json`. Copy the two server entries there. |

## Known limitations

- Antigravity's custom-agent schema is still thinly documented. The built-in
  tool names above are the ones published by Google or observed in its SDK
  output. Check them against your version (see Troubleshooting).
- The script extractors are candidate finders. The agent is instructed to
  confirm every row by reading code, but unusual frameworks may produce
  incomplete candidate lists; the knowledge graph covers most of those gaps.
- The package was tested with scripts against sample Java/Kotlin/Spring and
  Express repositories, under macOS bash 3.2 and bash 5. A full Antigravity
  session could not be exercised outside Antigravity itself, so run the
  smoke test above on first use.
